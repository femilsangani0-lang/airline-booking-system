import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ProtectedRoute from './components/ProtectedRoute';

// Pages
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import FlightSearchPage from './pages/FlightSearchPage';
import PassengerDetailsPage from './pages/PassengerDetailsPage';
import PaymentPage from './pages/PaymentPage';
import BookingConfirmationPage from './pages/BookingConfirmationPage';
import MyBookingsPage from './pages/MyBookingsPage';

function App() {
  return (
    <div className="d-flex flex-column min-vh-100">
      <Navbar />
      <main className="flex-grow-1">
        <Routes>
          {/* Page 1: Home */}
          <Route path="/" element={<HomePage />} />

          {/* Page 2: Login */}
          <Route path="/login" element={<LoginPage />} />

          {/* Page 3: Signup */}
          <Route path="/signup" element={<SignupPage />} />

          {/* Page 4: Flight Search */}
          <Route path="/flights" element={<FlightSearchPage />} />

          {/* Page 5: Passenger Details (Protected) */}
          <Route
            path="/booking/:flightId"
            element={
              <ProtectedRoute>
                <PassengerDetailsPage />
              </ProtectedRoute>
            }
          />

          {/* Page 6: Payment (Protected) */}
          <Route
            path="/payment"
            element={
              <ProtectedRoute>
                <PaymentPage />
              </ProtectedRoute>
            }
          />

          {/* Page 7: Booking Confirmation (Protected) */}
          <Route
            path="/confirmation/:id"
            element={
              <ProtectedRoute>
                <BookingConfirmationPage />
              </ProtectedRoute>
            }
          />

          {/* Page 7B: My Bookings (Protected) */}
          <Route
            path="/my-bookings"
            element={
              <ProtectedRoute>
                <MyBookingsPage />
              </ProtectedRoute>
            }
          />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;
