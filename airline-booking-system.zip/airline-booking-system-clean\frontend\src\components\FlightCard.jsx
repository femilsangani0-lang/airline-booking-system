import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useBooking } from '../context/BookingContext';

const FlightCard = ({ flight }) => {
  const navigate = useNavigate();
  const { setSelectedFlight, searchParams } = useBooking();

  const handleSelectFlight = () => {
    setSelectedFlight(flight);
    navigate(`/booking/${flight._id}`);
  };

  const getAirlineClass = (airline) => {
    const name = airline.toLowerCase();
    if (name.includes('indigo')) return 'airline-indigo';
    if (name.includes('air india')) return 'airline-airindia';
    if (name.includes('vistara')) return 'airline-vistara';
    if (name.includes('spicejet')) return 'airline-spicejet';
    if (name.includes('akasa')) return 'airline-akasa';
    return 'airline-emirates';
  };

  const getAirlineIcon = (airline) => {
    const name = airline.toLowerCase();
    if (name.includes('indigo')) return '6E';
    if (name.includes('air india')) return 'AI';
    if (name.includes('vistara')) return 'UK';
    if (name.includes('spicejet')) return 'SG';
    if (name.includes('akasa')) return 'QP';
    return 'EK';
  };

  const passengersCount = searchParams.passengers || 1;
  const totalPrice = flight.price * passengersCount;

  return (
    <div className="flight-result-card p-3 p-md-4 mb-3">
      <div className="row align-items-center g-3">
        <div className="col-12 col-md-3">
          <div className="d-flex align-items-center gap-3">
            <div className={`airline-badge ${getAirlineClass(flight.airline)}`}>
              {getAirlineIcon(flight.airline)}
            </div>
            <div>
              <h6 className="mb-0 fw-bold text-dark">{flight.airline}</h6>
              <span className="badge bg-light text-secondary border px-2 py-1 small">{flight.flightNumber}</span>
              <div className="mt-1">
                <span className={`badge ${flight.class === 'Business' ? 'bg-warning text-dark' : 'bg-primary-subtle text-primary'}`}>
                  {flight.class}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-6">
          <div className="d-flex align-items-center justify-content-between text-center">
            <div className="text-start" style={{ minWidth: '85px' }}>
              <h5 className="mb-0 fw-bold text-dark">{flight.departureTime}</h5>
              <p className="mb-0 small fw-semibold text-secondary text-truncate" style={{ maxWidth: '110px' }}>{flight.from}</p>
            </div>

            <div className="flex-grow-1 px-2 px-md-3">
              <div className="small text-muted mb-1 fw-medium">{flight.duration}</div>
              <div className="flight-route-line">
                <i className="bi bi-airplane-fill flight-route-plane"></i>
              </div>
              <div className="small text-success mt-1 fw-semibold">
                <i className="bi bi-check2-circle me-1"></i>Non-stop
              </div>
            </div>

            <div className="text-end" style={{ minWidth: '85px' }}>
              <h5 className="mb-0 fw-bold text-dark">{flight.arrivalTime}</h5>
              <p className="mb-0 small fw-semibold text-secondary text-truncate" style={{ maxWidth: '110px' }}>{flight.to}</p>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-3 text-md-end border-start-md pt-3 pt-md-0">
          <div className="d-flex flex-row flex-md-column justify-content-between align-items-center align-items-md-end gap-2">
            <div>
              <div className="small text-muted">Starting from</div>
              <h4 className="mb-0 fw-bold text-primary">₹{flight.price.toLocaleString('en-IN')}</h4>
              {passengersCount > 1 && (
                <div className="small text-muted">₹{totalPrice.toLocaleString('en-IN')} total ({passengersCount} pax)</div>
              )}
            </div>

            <div className="d-flex flex-column align-items-end gap-1">
              <button
                className="btn btn-primary px-4 py-2 rounded-pill fw-semibold shadow-sm text-nowrap"
                onClick={handleSelectFlight}
                disabled={flight.availableSeats <= 0}
              >
                {flight.availableSeats > 0 ? (
                  <>Book Now <i className="bi bi-arrow-right ms-1"></i></>
                ) : (
                  'Sold Out'
                )}
              </button>
              <div className="small text-muted">
                <i className="bi bi-person-check text-success me-1"></i>
                <span className={flight.availableSeats < 15 ? 'text-danger fw-bold' : ''}>
                  {flight.availableSeats} seats left
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FlightCard;
