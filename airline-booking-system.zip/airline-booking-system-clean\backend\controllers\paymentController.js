const Payment = require('../models/Payment');
const Booking = require('../models/Booking');

const generateTransactionId = () => {
  return 'TXN-' + Math.floor(100000000 + Math.random() * 900000000);
};

const processPayment = async (req, res) => {
  try {
    const { bookingId, amount, paymentMethod, cardNumber } = req.body;

    if (!bookingId || !amount || !paymentMethod) {
      return res.status(400).json({ success: false, message: 'Booking ID, amount, and payment method are required' });
    }

    const booking = await Booking.findById(bookingId);
    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    let cardLast4 = '';
    if (cardNumber && cardNumber.length >= 4) {
      cardLast4 = cardNumber.slice(-4);
    }

    const transactionId = generateTransactionId();

    const payment = await Payment.create({
      bookingId: booking._id,
      userId: req.user._id,
      amount,
      paymentMethod,
      paymentStatus: 'Successful',
      transactionId,
      cardLast4
    });

    booking.paymentStatus = 'Successful';
    await booking.save();

    res.status(201).json({
      success: true,
      message: 'Payment processed successfully!',
      data: {
        transactionId: payment.transactionId,
        paymentStatus: payment.paymentStatus,
        paymentMethod: payment.paymentMethod,
        amount: payment.amount,
        createdAt: payment.createdAt
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getPaymentByBooking = async (req, res) => {
  try {
    const payment = await Payment.findOne({ bookingId: req.params.bookingId });
    if (!payment) {
      return res.status(404).json({ success: false, message: 'Payment record not found' });
    }

    res.status(200).json({
      success: true,
      data: payment
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { processPayment, getPaymentByBooking };
