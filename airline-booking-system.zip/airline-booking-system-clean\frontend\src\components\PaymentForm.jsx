import React, { useState } from 'react';

const PaymentForm = ({ onSubmit, loading, totalAmount }) => {
  const [paymentMethod, setPaymentMethod] = useState('Credit Card');
  const [cardholderName, setCardholderName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [upiId, setUpiId] = useState('');
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');

  const handleCardNumberChange = (e) => {
    let value = e.target.value.replace(/\D/g, '').slice(0, 16);
    let formatted = value.match(/.{1,4}/g)?.join(' ') || value;
    setCardNumber(formatted);
  };

  const handleExpiryChange = (e) => {
    let value = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (value.length >= 3) {
      value = value.slice(0, 2) + '/' + value.slice(2);
    }
    setExpiry(value);
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      paymentMethod,
      cardNumber: cardNumber.replace(/\s/g, ''),
      cardholderName,
      upiId,
      bank: selectedBank
    });
  };

  return (
    <div className="card border-0 shadow-sm rounded-4">
      <div className="card-header bg-light p-3">
        <ul className="nav nav-pills nav-fill gap-2" role="tablist">
          <li className="nav-item">
            <button
              type="button"
              className={`nav-link py-2 fw-semibold rounded-3 ${paymentMethod === 'Credit Card' ? 'active shadow-sm' : ''}`}
              onClick={() => setPaymentMethod('Credit Card')}
            >
              <i className="bi bi-credit-card-2-front me-2"></i> Credit / Debit Card
            </button>
          </li>
          <li className="nav-item">
            <button
              type="button"
              className={`nav-link py-2 fw-semibold rounded-3 ${paymentMethod === 'UPI' ? 'active shadow-sm' : ''}`}
              onClick={() => setPaymentMethod('UPI')}
            >
              <i className="bi bi-qr-code-scan me-2"></i> UPI / QR Code
            </button>
          </li>
          <li className="nav-item">
            <button
              type="button"
              className={`nav-link py-2 fw-semibold rounded-3 ${paymentMethod === 'Net Banking' ? 'active shadow-sm' : ''}`}
              onClick={() => setPaymentMethod('Net Banking')}
            >
              <i className="bi bi-bank me-2"></i> Net Banking
            </button>
          </li>
        </ul>
      </div>

      <div className="card-body p-4">
        <form onSubmit={handleFormSubmit}>
          {paymentMethod === 'Credit Card' && (
            <div className="row g-3">
              <div className="col-12">
                <div className="alert alert-info py-2 px-3 small d-flex align-items-center gap-2">
                  <i className="bi bi-shield-lock-fill fs-5"></i>
                  <span>Demo Mode: You can enter any mock card details (e.g. 4111 2222 3333 4444). CVV is never stored.</span>
                </div>
              </div>

              <div className="col-12">
                <label className="form-label small fw-bold text-secondary">Cardholder Name</label>
                <input
                  type="text"
                  className="form-control py-2"
                  placeholder="e.g. Rahul Sharma"
                  value={cardholderName}
                  onChange={(e) => setCardholderName(e.target.value)}
                  required
                />
              </div>

              <div className="col-12">
                <label className="form-label small fw-bold text-secondary">Card Number</label>
                <div className="input-group">
                  <span className="input-group-text bg-white"><i className="bi bi-credit-card"></i></span>
                  <input
                    type="text"
                    className="form-control py-2"
                    placeholder="4111 2222 3333 4444"
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    required
                  />
                </div>
              </div>

              <div className="col-6">
                <label className="form-label small fw-bold text-secondary">Expiry Date (MM/YY)</label>
                <input
                  type="text"
                  className="form-control py-2"
                  placeholder="12/28"
                  value={expiry}
                  onChange={handleExpiryChange}
                  required
                />
              </div>

              <div className="col-6">
                <label className="form-label small fw-bold text-secondary">CVV</label>
                <input
                  type="password"
                  className="form-control py-2"
                  placeholder="•••"
                  maxLength={4}
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
                  required
                />
              </div>
            </div>
          )}

          {paymentMethod === 'UPI' && (
            <div className="text-center py-3">
              <div className="bg-light p-3 rounded-4 d-inline-block mb-3 border">
                <div className="bg-white p-3 rounded-3 shadow-sm d-inline-block">
                  <i className="bi bi-qr-code text-dark" style={{ fontSize: '6rem' }}></i>
                </div>
                <p className="small text-muted mt-2 mb-0">Scan & Pay using GPay, PhonePe, Paytm</p>
              </div>

              <div className="col-md-8 mx-auto text-start">
                <label className="form-label small fw-bold text-secondary">Or enter your UPI ID</label>
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control py-2"
                    placeholder="username@okhdfcbank"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    required
                  />
                  <span className="input-group-text bg-light fw-bold text-primary">@UPI</span>
                </div>
              </div>
            </div>
          )}

          {paymentMethod === 'Net Banking' && (
            <div className="py-2">
              <label className="form-label small fw-bold text-secondary mb-3">Select Popular Bank</label>
              <div className="row g-2 mb-3">
                {['HDFC Bank', 'State Bank of India', 'ICICI Bank', 'Axis Bank', 'Kotak Mahindra'].map((b) => (
                  <div key={b} className="col-6 col-md-4">
                    <button
                      type="button"
                      className={`btn w-100 py-2 small fw-semibold text-truncate ${selectedBank === b ? 'btn-primary' : 'btn-outline-secondary'}`}
                      onClick={() => setSelectedBank(b)}
                    >
                      {b}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="mt-4 pt-3 border-top">
            <button
              type="submit"
              className="btn btn-success w-100 py-3 rounded-pill fw-bold fs-5 shadow"
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  Processing Payment...
                </>
              ) : (
                <>
                  <i className="bi bi-lock-fill me-2"></i> Pay ₹{totalAmount.toLocaleString('en-IN')} Now
                </>
              )}
            </button>
            <div className="text-center mt-2 small text-muted">
              <i className="bi bi-shield-check text-success me-1"></i> Encrypted with 256-bit SSL Security
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PaymentForm;
