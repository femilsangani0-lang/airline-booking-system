import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useBooking } from '../context/BookingContext';
import { useAuth } from '../context/AuthContext';
import { bookingService } from '../services/bookingService';
import { paymentService } from '../services/paymentService';
import PaymentForm from '../components/PaymentForm';
import BookingSummary from '../components/BookingSummary';
import AlertMessage from '../components/AlertMessage';

const PaymentPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { selectedFlight, passengersData, searchParams, setCurrentBooking } = useBooking();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const count = searchParams.passengers || (passengersData?.length) || 1;
  const baseFare = (selectedFlight?.price || 4500) * count;
  const taxes = Math.round(baseFare * 0.12);
  const serviceCharges = 150;
  const grandTotal = baseFare + taxes + serviceCharges;

  const handlePaymentProcessing = async (paymentFormData) => {
    if (!selectedFlight) {
      setError('Selected flight expired or not found. Please start over.');
      return;
    }

    if (!passengersData || passengersData.length === 0) {
      setError('Passenger details are missing. Please go back and enter passenger info.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // 1. Create Booking in MongoDB
      const bookingPayload = {
        flightId: selectedFlight._id,
        passengers: passengersData,
        numberOfPassengers: count,
        travelClass: searchParams.travelClass || selectedFlight.class || 'Economy',
        baseFare,
        taxes,
        serviceCharges,
        totalAmount: grandTotal,
        paymentMethod: paymentFormData.paymentMethod
      };

      const bookingRes = await bookingService.createBooking(bookingPayload);

      if (!bookingRes.success || !bookingRes.data) {
        throw new Error(bookingRes.message || 'Failed to create booking');
      }

      const createdBooking = bookingRes.data;

      // 2. Process Demo Payment record in MongoDB
      const paymentPayload = {
        bookingId: createdBooking._id,
        amount: grandTotal,
        paymentMethod: paymentFormData.paymentMethod,
        cardNumber: paymentFormData.cardNumber
      };

      await paymentService.processPayment(paymentPayload);

      // Save into context for immediate confirmation view
      setCurrentBooking(createdBooking);

      // 3. Redirect to Confirmation Page
      navigate(`/confirmation/${createdBooking._id}`, { replace: true });
    } catch (err) {
      console.error('Payment / Booking error:', err);
      setError(err.response?.data?.message || err.message || 'Payment processing failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!selectedFlight) {
    return (
      <div className="container py-5 text-center">
        <h4>No flight in active checkout</h4>
        <p className="text-muted">Please search and select a flight before checkout.</p>
        <Link to="/flights" className="btn btn-primary rounded-pill px-4">Search Flights</Link>
      </div>
    );
  }

  return (
    <div className="py-4 bg-light">
      <div className="container">
        {/* Step Indicator */}
        <div className="d-flex align-items-center gap-2 mb-4 small text-muted">
          <Link to="/" className="text-decoration-none text-muted">Home</Link>
          <i className="bi bi-chevron-right"></i>
          <Link to="/flights" className="text-decoration-none text-muted">Flight Search</Link>
          <i className="bi bi-chevron-right"></i>
          <Link to={`/booking/${selectedFlight._id}`} className="text-decoration-none text-muted">Passenger Details</Link>
          <i className="bi bi-chevron-right"></i>
          <span className="text-primary fw-bold">Secure Payment</span>
        </div>

        <AlertMessage message={error} onClose={() => setError('')} />

        <div className="row g-4">
          <div className="col-12 col-lg-8">
            {/* Passenger Count Badge banner */}
            <div className="alert alert-success bg-white border-0 shadow-sm rounded-4 p-3 mb-4 d-flex align-items-center justify-content-between">
              <div className="d-flex align-items-center gap-2">
                <i className="bi bi-person-check-fill text-success fs-4"></i>
                <div>
                  <h6 className="mb-0 fw-bold text-dark">{count} Passenger(s) Verified</h6>
                  <span className="small text-muted">Primary: {passengersData[0]?.fullName || user?.fullName} ({passengersData[0]?.email || user?.email})</span>
                </div>
              </div>
              <Link to={`/booking/${selectedFlight._id}`} className="btn btn-outline-secondary btn-sm rounded-pill">
                Edit
              </Link>
            </div>

            {/* Payment Method & Interactive Form */}
            <PaymentForm
              onSubmit={handlePaymentProcessing}
              loading={loading}
              totalAmount={grandTotal}
            />
          </div>

          {/* Sticky Summary */}
          <div className="col-12 col-lg-4">
            <BookingSummary flight={selectedFlight} numberOfPassengers={count} showPromo={false} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;
