import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import SearchForm from '../components/SearchForm';
import FlightCard from '../components/FlightCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { flightService } from '../services/flightService';

const popularDestinations = [
  { city: 'Mumbai', code: 'BOM', state: 'Maharashtra', image: 'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=600&auto=format&fit=crop&q=60', price: 2800 },
  { city: 'Delhi', code: 'DEL', state: 'National Capital', image: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?w=600&auto=format&fit=crop&q=60', price: 3100 },
  { city: 'Goa', code: 'GOI', state: 'Beach Paradise', image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=600&auto=format&fit=crop&q=60', price: 2499 },
  { city: 'Bangalore', code: 'BLR', state: 'Silicon Valley', image: 'https://images.unsplash.com/photo-1596176530529-78163a4f7af2?w=600&auto=format&fit=crop&q=60', price: 3400 },
  { city: 'Dubai', code: 'DXB', state: 'United Arab Emirates', image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600&auto=format&fit=crop&q=60', price: 16900 },
  { city: 'Ahmedabad', code: 'AMD', state: 'Heritage City', image: 'https://images.unsplash.com/photo-1609137144813-7d9921338f24?w=600&auto=format&fit=crop&q=60', price: 2650 }
];

const HomePage = () => {
  const [featuredFlights, setFeaturedFlights] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeatured = async () => {
      try {
        const res = await flightService.getFeaturedFlights();
        if (res.success && res.data) {
          setFeaturedFlights(res.data);
        }
      } catch (err) {
        console.error('Failed to load featured flights:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchFeatured();
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="hero-wrapper text-center">
        <div className="container position-relative z-2">
          <span className="badge bg-light text-primary px-3 py-2 rounded-pill fw-bold mb-3 shadow-sm">
            <i className="bi bi-stars me-1 text-warning"></i> Fly Above the Rest
          </span>
          <h1 className="display-4 fw-extrabold mb-3 text-white">
            Book Your Next Flight With Ease
          </h1>
          <p className="lead text-light opacity-90 mx-auto mb-4" style={{ maxWidth: '680px' }}>
            Discover incredible domestic & international airfares. Seamless bookings, instant PNRs, and 24/7 passenger assistance.
          </p>
        </div>
      </section>

      {/* Floating Flight Search Card */}
      <div className="container">
        <SearchForm isHero={true} />
      </div>

      {/* Popular Destinations */}
      <section className="py-5 my-3">
        <div className="container">
          <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-end mb-4">
            <div>
              <span className="text-primary fw-bold text-uppercase small letter-spacing-1">Top Getaways</span>
              <h2 className="fw-bold text-dark mb-0">Popular Destinations</h2>
            </div>
            <Link to="/flights" className="text-primary fw-semibold text-decoration-none mt-2 mt-md-0">
              View All Routes <i className="bi bi-arrow-right"></i>
            </Link>
          </div>

          <div className="row g-4">
            {popularDestinations.map((dest) => (
              <div key={dest.code} className="col-12 col-sm-6 col-lg-4">
                <Link to={`/flights?to=${dest.city}`} className="text-decoration-none">
                  <div className="card border-0 rounded-4 overflow-hidden shadow-sm h-100 position-relative group" style={{ transition: 'all 0.3s ease' }}>
                    <div style={{ height: '220px', overflow: 'hidden' }}>
                      <img
                        src={dest.image}
                        alt={dest.city}
                        className="w-100 h-100 object-fit-cover"
                        style={{ transition: 'transform 0.4s ease' }}
                        onError={(e) => {
                          e.target.src = 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=600&auto=format&fit=crop&q=60';
                        }}
                      />
                    </div>
                    <div className="card-body p-3 bg-white d-flex justify-content-between align-items-center">
                      <div>
                        <h5 className="mb-0 fw-bold text-dark">{dest.city} ({dest.code})</h5>
                        <small className="text-muted">{dest.state}</small>
                      </div>
                      <div className="text-end">
                        <span className="small text-muted d-block">From</span>
                        <span className="fw-bold text-primary fs-5">₹{dest.price.toLocaleString('en-IN')}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Flights Grid */}
      <section className="py-5 bg-white border-top border-bottom">
        <div className="container">
          <div className="text-center mb-5">
            <span className="badge bg-primary-subtle text-primary px-3 py-2 rounded-pill fw-bold mb-2">
              <i className="bi bi-fire text-danger me-1"></i> Today's Best Fares
            </span>
            <h2 className="fw-bold text-dark">Featured Flight Deals</h2>
            <p className="text-muted">Hand-picked lowest fare options available for this week</p>
          </div>

          {loading ? (
            <LoadingSpinner message="Fetching live featured flight fares..." />
          ) : featuredFlights.length > 0 ? (
            <div className="row">
              <div className="col-12 col-lg-10 mx-auto">
                {featuredFlights.map((flight) => (
                  <FlightCard key={flight._id} flight={flight} />
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-muted">No featured flights loaded. Try searching all flights.</p>
              <Link to="/flights" className="btn btn-primary rounded-pill px-4">Browse All Flights</Link>
            </div>
          )}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-5 my-4">
        <div className="container">
          <div className="text-center mb-5">
            <span className="text-primary fw-bold text-uppercase small">Our Advantages</span>
            <h2 className="fw-bold text-dark">Why Choose SkyWings Airlines?</h2>
            <p className="text-muted">Experience first-class service from booking to landing</p>
          </div>

          <div className="row g-4 text-center">
            <div className="col-12 col-md-6 col-lg-3">
              <div className="card h-100 border-0 p-4 rounded-4 shadow-sm bg-white">
                <div className="bg-primary-subtle text-primary rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style={{ width: '64px', height: '64px' }}>
                  <i className="bi bi-tag-fill fs-3"></i>
                </div>
                <h5 className="fw-bold mb-2">Best Price Guarantee</h5>
                <p className="text-muted small mb-0">Competitive ticket pricing with no hidden charges or inflated surge fees.</p>
              </div>
            </div>

            <div className="col-12 col-md-6 col-lg-3">
              <div className="card h-100 border-0 p-4 rounded-4 shadow-sm bg-white">
                <div className="bg-success-subtle text-success rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style={{ width: '64px', height: '64px' }}>
                  <i className="bi bi-shield-lock-fill fs-3"></i>
                </div>
                <h5 className="fw-bold mb-2">100% Secure Payments</h5>
                <p className="text-muted small mb-0">Multi-layer encryption with support for Card, UPI, and Net Banking checkouts.</p>
              </div>
            </div>

            <div className="col-12 col-md-6 col-lg-3">
              <div className="card h-100 border-0 p-4 rounded-4 shadow-sm bg-white">
                <div className="bg-warning-subtle text-warning rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style={{ width: '64px', height: '64px' }}>
                  <i className="bi bi-ticket-perforated-fill fs-3"></i>
                </div>
                <h5 className="fw-bold mb-2">Instant PNR & E-Ticket</h5>
                <p className="text-muted small mb-0">Immediate boarding pass generation with printable PDF e-tickets.</p>
              </div>
            </div>

            <div className="col-12 col-md-6 col-lg-3">
              <div className="card h-100 border-0 p-4 rounded-4 shadow-sm bg-white">
                <div className="bg-info-subtle text-info rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style={{ width: '64px', height: '64px' }}>
                  <i className="bi bi-headset fs-3"></i>
                </div>
                <h5 className="fw-bold mb-2">24/7 Dedicated Support</h5>
                <p className="text-muted small mb-0">Round-the-clock passenger assistance for flight changes and cancellations.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Customer Reviews / Testimonials */}
      <section className="py-5 bg-light border-top">
        <div className="container">
          <div className="text-center mb-5">
            <span className="text-primary fw-bold text-uppercase small">Passenger Feedback</span>
            <h2 className="fw-bold text-dark">What Our Travelers Say</h2>
          </div>

          <div className="row g-4">
            <div className="col-12 col-md-4">
              <div className="card border-0 shadow-sm rounded-4 p-4 h-100 bg-white">
                <div className="d-flex text-warning mb-3">
                  {[...Array(5)].map((_, i) => <i key={i} className="bi bi-star-fill me-1"></i>)}
                </div>
                <p className="text-muted small mb-3">"Booking through SkyWings was unbelievably fast. I searched for flights from Mumbai to Delhi, booked my seats in under 2 minutes, and printed my boarding pass instantly."</p>
                <div className="d-flex align-items-center gap-2 mt-auto">
                  <div className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style={{ width: '36px', height: '36px' }}>P</div>
                  <div>
                    <h6 className="mb-0 fw-bold small text-dark">Priya Mehta</h6>
                    <small className="text-muted">Frequent Business Traveler</small>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-12 col-md-4">
              <div className="card border-0 shadow-sm rounded-4 p-4 h-100 bg-white">
                <div className="d-flex text-warning mb-3">
                  {[...Array(5)].map((_, i) => <i key={i} className="bi bi-star-fill me-1"></i>)}
                </div>
                <p className="text-muted small mb-3">"The user interface is so clean and responsive. I booked flights for my entire family to Goa with multiple passengers without any hitch. Highly recommend!"</p>
                <div className="d-flex align-items-center gap-2 mt-auto">
                  <div className="bg-success text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style={{ width: '36px', height: '36px' }}>A</div>
                  <div>
                    <h6 className="mb-0 fw-bold small text-dark">Amit Patel</h6>
                    <small className="text-muted">Family Vacationer</small>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-12 col-md-4">
              <div className="card border-0 shadow-sm rounded-4 p-4 h-100 bg-white">
                <div className="d-flex text-warning mb-3">
                  {[...Array(5)].map((_, i) => <i key={i} className="bi bi-star-fill me-1"></i>)}
                </div>
                <p className="text-muted small mb-3">"Cancelled one of my bookings when my plans changed and the refund process was smooth and immediate. The college project interface is very impressive!"</p>
                <div className="d-flex align-items-center gap-2 mt-auto">
                  <div className="bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center fw-bold" style={{ width: '36px', height: '36px' }}>S</div>
                  <div>
                    <h6 className="mb-0 fw-bold small text-dark">Sneha Rao</h6>
                    <small className="text-muted">Solo Explorer</small>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
