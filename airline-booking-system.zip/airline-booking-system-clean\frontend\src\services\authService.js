import API from './api';

export const authService = {
  signup: async (userData) => {
    const response = await API.post('/auth/signup', userData);
    return response.data;
  },
  login: async (credentials) => {
    const response = await API.post('/auth/login', credentials);
    return response.data;
  },
  getProfile: async () => {
    const response = await API.get('/auth/profile');
    return response.data;
  }
};
