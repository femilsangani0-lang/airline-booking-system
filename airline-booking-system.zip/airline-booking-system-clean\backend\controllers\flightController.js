const Flight = require('../models/Flight');

const getFlights = async (req, res) => {
  try {
    const { from, to, date, travelClass, minPrice, maxPrice, airline, sort } = req.query;
    let query = {};

    if (from) {
      query.from = new RegExp(from, 'i');
    }
    if (to) {
      query.to = new RegExp(to, 'i');
    }
    if (travelClass && travelClass !== 'All') {
      query.class = travelClass;
    }
    if (airline && airline !== 'All') {
      query.airline = new RegExp(airline, 'i');
    }
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = Number(minPrice);
      if (maxPrice) query.price.$lte = Number(maxPrice);
    }

    if (date) {
      const searchDate = new Date(date);
      const startOfDay = new Date(searchDate.setHours(0, 0, 0, 0));
      const endOfDay = new Date(searchDate.setHours(23, 59, 59, 999));
      query.departureDate = { $gte: startOfDay, $lte: endOfDay };
    }

    let sortOption = { price: 1 };
    if (sort === 'price_desc' || sort === 'price_high') sortOption = { price: -1 };
    if (sort === 'departure_asc' || sort === 'departure_time') sortOption = { departureTime: 1 };
    if (sort === 'duration_asc' || sort === 'duration') sortOption = { duration: 1 };

    const flights = await Flight.find(query).sort(sortOption);

    res.status(200).json({
      success: true,
      count: flights.length,
      data: flights
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const searchFlights = async (req, res) => {
  try {
    const { from, to, departureDate, travelClass, passengers, airline, maxPrice, sort } = req.body;
    let query = {};

    if (from) {
      query.from = { $regex: from.trim(), $options: 'i' };
    }
    if (to) {
      query.to = { $regex: to.trim(), $options: 'i' };
    }
    if (travelClass && travelClass !== 'All') {
      query.class = travelClass;
    }
    if (airline && airline !== 'All') {
      query.airline = { $regex: airline.trim(), $options: 'i' };
    }
    if (maxPrice) {
      query.price = { $lte: Number(maxPrice) };
    }
    if (passengers) {
      query.availableSeats = { $gte: Number(passengers) };
    }

    if (departureDate) {
      const searchDate = new Date(departureDate);
      const startOfDay = new Date(searchDate.setUTCHours(0, 0, 0, 0));
      const endOfDay = new Date(searchDate.setUTCHours(23, 59, 59, 999));
      query.departureDate = { $gte: startOfDay, $lte: endOfDay };
    }

    let sortOption = { price: 1 };
    if (sort === 'price_high' || sort === 'price_desc') sortOption = { price: -1 };
    if (sort === 'departure_time' || sort === 'departure_asc') sortOption = { departureTime: 1 };
    if (sort === 'duration' || sort === 'duration_asc') sortOption = { duration: 1 };

    let flights = await Flight.find(query).sort(sortOption);

    // Fallback if zero found on exact date: return route flights for user convenience
    if (flights.length === 0 && (from || to)) {
      const fallbackQuery = {};
      if (from) fallbackQuery.from = { $regex: from.trim(), $options: 'i' };
      if (to) fallbackQuery.to = { $regex: to.trim(), $options: 'i' };
      flights = await Flight.find(fallbackQuery).sort(sortOption).limit(10);
    }

    res.status(200).json({
      success: true,
      count: flights.length,
      data: flights
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getFlightById = async (req, res) => {
  try {
    const flight = await Flight.findById(req.params.id);
    if (!flight) {
      return res.status(404).json({ success: false, message: 'Flight not found' });
    }
    res.status(200).json({
      success: true,
      data: flight
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getFeaturedFlights = async (req, res) => {
  try {
    const featured = await Flight.find({ status: 'On Time' }).limit(6).sort({ price: 1 });
    res.status(200).json({
      success: true,
      data: featured
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getFlights, searchFlights, getFlightById, getFeaturedFlights };
