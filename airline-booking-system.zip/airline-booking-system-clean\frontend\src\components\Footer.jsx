import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-dark text-white pt-5 pb-4 mt-auto no-print" style={{ backgroundColor: '#07152f' }}>
      <div className="container">
        <div className="row g-4">
          <div className="col-lg-4 col-md-6">
            <div className="d-flex align-items-center gap-2 mb-3">
              <div className="bg-primary text-white rounded-3 p-1 d-flex align-items-center justify-content-center" style={{ width: '32px', height: '32px' }}>
                <i className="bi bi-airplane-fill fs-6"></i>
              </div>
              <h5 className="mb-0 fw-bold">SkyWings <span className="text-primary">Airlines</span></h5>
            </div>
            <p className="text-secondary small mb-3">
              SkyWings Airlines is a modern, reliable airline booking platform providing domestic and international flights at competitive fares with 24/7 dedicated passenger assistance.
            </p>
            <div className="d-flex gap-3 text-secondary">
              <span className="badge bg-secondary bg-opacity-25 text-light p-2 rounded-3"><i className="bi bi-shield-check text-success me-1"></i> 100% Secure Checkout</span>
              <span className="badge bg-secondary bg-opacity-25 text-light p-2 rounded-3"><i className="bi bi-clock-history text-info me-1"></i> 24/7 Support</span>
            </div>
          </div>

          <div className="col-lg-2 col-md-6 col-6">
            <h6 className="text-uppercase fw-bold text-light mb-3">Quick Links</h6>
            <ul className="list-unstyled text-secondary small d-flex flex-column gap-2 mb-0">
              <li><Link to="/" className="text-secondary text-decoration-none">Home</Link></li>
              <li><Link to="/flights" className="text-secondary text-decoration-none">Search Flights</Link></li>
              <li><Link to="/my-bookings" className="text-secondary text-decoration-none">My Bookings</Link></li>
              <li><Link to="/login" className="text-secondary text-decoration-none">Sign In</Link></li>
              <li><Link to="/signup" className="text-secondary text-decoration-none">Register</Link></li>
            </ul>
          </div>

          <div className="col-lg-3 col-md-6 col-6">
            <h6 className="text-uppercase fw-bold text-light mb-3">Popular Routes</h6>
            <ul className="list-unstyled text-secondary small d-flex flex-column gap-2 mb-0">
              <li><Link to="/flights?from=Mumbai&to=Delhi" className="text-secondary text-decoration-none">Mumbai → Delhi</Link></li>
              <li><Link to="/flights?from=Delhi&to=Bangalore" className="text-secondary text-decoration-none">Delhi → Bangalore</Link></li>
              <li><Link to="/flights?from=Ahmedabad&to=Mumbai" className="text-secondary text-decoration-none">Ahmedabad → Mumbai</Link></li>
              <li><Link to="/flights?from=Mumbai&to=Goa" className="text-secondary text-decoration-none">Mumbai → Goa</Link></li>
              <li><Link to="/flights?from=Mumbai&to=Dubai" className="text-secondary text-decoration-none">Mumbai → Dubai</Link></li>
            </ul>
          </div>

          <div className="col-lg-3 col-md-6">
            <h6 className="text-uppercase fw-bold text-light mb-3">Customer Support</h6>
            <p className="text-secondary small mb-2"><i className="bi bi-telephone-fill text-primary me-2"></i> +91 1800-209-SKYWINGS</p>
            <p className="text-secondary small mb-2"><i className="bi bi-envelope-fill text-primary me-2"></i> support@skywings.com</p>
            <p className="text-secondary small mb-3"><i className="bi bi-geo-alt-fill text-primary me-2"></i> Terminal 2, Chhatrapati Shivaji Int'l Airport, Mumbai</p>
          </div>
        </div>

        <hr className="border-secondary my-4 opacity-25" />

        <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2 small text-secondary">
          <p className="mb-0">© {new Date().getFullYear()} SkyWings Airlines. Advanced Web Designing College Project.</p>
          <div className="d-flex gap-3">
            <span>Privacy Policy</span>
            <span>Terms of Service</span>
            <span>Baggage Policy</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
