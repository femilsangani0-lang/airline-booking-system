const express = require('express');
const router = express.Router();
const { getFlights, searchFlights, getFlightById, getFeaturedFlights } = require('../controllers/flightController');

router.get('/', getFlights);
router.post('/search', searchFlights);
router.get('/featured', getFeaturedFlights);
router.get('/:id', getFlightById);

module.exports = router;
