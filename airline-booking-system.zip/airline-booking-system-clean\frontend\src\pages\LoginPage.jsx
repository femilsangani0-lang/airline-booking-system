import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import AlertMessage from '../components/AlertMessage';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showForgotModal, setShowForgotModal] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const redirectPath = location.state?.from?.pathname || '/';

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const res = await login(email, password);
    setLoading(false);

    if (res.success) {
      navigate(redirectPath, { replace: true });
    } else {
      setError(res.message);
    }
  };

  const handleDemoFill = () => {
    setEmail('demo@skywings.com');
    setPassword('password123');
  };

  return (
    <div className="container py-5 my-auto">
      <div className="row justify-content-center">
        <div className="col-12 col-md-8 col-lg-5">
          <div className="card border-0 shadow-lg rounded-4 overflow-hidden">
            {/* Header Banner */}
            <div className="bg-dark text-white p-4 text-center" style={{ backgroundColor: '#0b1f44' }}>
              <div className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-2" style={{ width: '48px', height: '48px' }}>
                <i className="bi bi-airplane-fill fs-4"></i>
              </div>
              <h4 className="fw-bold mb-1">Welcome Back</h4>
              <p className="small text-light opacity-75 mb-0">Sign in to your SkyWings account</p>
            </div>

            <div className="card-body p-4 p-md-5">
              <AlertMessage message={error} onClose={() => setError('')} />

              <form onSubmit={handleLoginSubmit}>
                {/* Email */}
                <div className="mb-3">
                  <label className="form-label small fw-bold text-secondary">Email Address</label>
                  <div className="input-group">
                    <span className="input-group-text bg-light"><i className="bi bi-envelope text-muted"></i></span>
                    <input
                      type="email"
                      className="form-control py-2"
                      placeholder="name@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="mb-3">
                  <div className="d-flex justify-content-between">
                    <label className="form-label small fw-bold text-secondary">Password</label>
                    <button
                      type="button"
                      className="btn btn-link p-0 small text-decoration-none"
                      onClick={() => setShowForgotModal(true)}
                    >
                      Forgot Password?
                    </button>
                  </div>
                  <div className="input-group">
                    <span className="input-group-text bg-light"><i className="bi bi-lock text-muted"></i></span>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      className="form-control py-2"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                    <button
                      type="button"
                      className="btn btn-light border"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      <i className={`bi ${showPassword ? 'bi-eye-slash' : 'bi-eye'}`}></i>
                    </button>
                  </div>
                </div>

                {/* Remember Me */}
                <div className="form-check mb-4">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="rememberMe"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                  />
                  <label className="form-check-label small text-secondary" htmlFor="rememberMe">
                    Remember me on this browser
                  </label>
                </div>

                {/* Submit */}
                <button
                  type="submit"
                  className="btn btn-primary w-100 py-2 rounded-pill fw-bold shadow-sm mb-3"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Signing In...
                    </>
                  ) : (
                    'Sign In'
                  )}
                </button>

                {/* Demo Quick-Fill Button */}
                <button
                  type="button"
                  className="btn btn-outline-secondary w-100 py-2 rounded-pill small fw-semibold mb-3"
                  onClick={handleDemoFill}
                >
                  <i className="bi bi-lightning-charge text-warning me-1"></i> Auto-fill Demo Credentials
                </button>
              </form>

              <p className="text-center small text-muted mb-0 mt-3">
                Don't have an account?{' '}
                <Link to="/signup" className="text-primary fw-bold text-decoration-none">
                  Create an account
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Forgot Password Demo Modal */}
      {showForgotModal && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content rounded-4 border-0">
              <div className="modal-header border-0 pb-0">
                <h5 className="modal-title fw-bold">Reset Password</h5>
                <button type="button" className="btn-close" onClick={() => setShowForgotModal(false)}></button>
              </div>
              <div className="modal-body p-4">
                <p className="text-muted small">Enter your registered email address to receive password reset instructions.</p>
                <div className="mb-3">
                  <input type="email" className="form-control" placeholder="Enter your email" defaultValue={email} />
                </div>
                <div className="alert alert-success small mb-0">
                  <i className="bi bi-info-circle me-1"></i> Demo Feature: Password reset link has been simulated. You can also use the default demo password: <code>password123</code>.
                </div>
              </div>
              <div className="modal-footer border-0 pt-0">
                <button type="button" className="btn btn-primary rounded-pill px-4" onClick={() => setShowForgotModal(false)}>
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LoginPage;
