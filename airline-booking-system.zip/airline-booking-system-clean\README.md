# ✈️ Airline Ticket Booking System ("SkyWings Airlines")

A complete, modern, responsive, and fully functional **Airline Ticket Booking Platform** built as a college Advanced Web Designing project.

---

## 📌 Project Overview

**SkyWings Airlines** is a full-stack airline reservation system allowing travelers to search domestic and international flights, compare fares, select seats, register passenger profiles, process demo payments securely, generate electronic boarding passes with unique PNR numbers, and manage/cancel their bookings with automated seat inventory management.

---

## 🛠️ Technology Stack

| Layer | Technology | Purpose |
|---|---|---|
| **Frontend Framework** | **React.js (Vite)** | Modular component-based Single Page Application (SPA) |
| **Styling & UI** | **HTML5, CSS3, Bootstrap 5** | Fully responsive layout, modern cards, aviation theme |
| **Icons & Fonts** | **Bootstrap Icons & Google Fonts** | Modern typography (Plus Jakarta Sans) and vector icons |
| **Client Routing** | **React Router v6** | Client-side navigation across all 7 main pages |
| **HTTP Client** | **Axios** | REST API calls with JWT Bearer authentication interceptor |
| **Backend Runtime** | **Node.js** | High-performance asynchronous server runtime |
| **Backend Framework** | **Express.js** | REST API endpoints, routing, error handling, CORS |
| **Authentication** | **JWT & Bcrypt.js** | Secure token-based session management & password hashing |
| **Database** | **MongoDB & Mongoose** | Document-oriented database for users, flights, bookings & payments |

---

## 🌐 7 Main Website Pages

### 1. Home Page (`/`)
- Hero section with aviation theme and flight search bar.
- Popular destinations grid (Mumbai, Delhi, Goa, Bangalore, Dubai, Ahmedabad) with live starting fares.
- Featured flight deals card list.
- "Why Choose Us" feature cards (Best Price Guarantee, 100% Secure Payments, Instant PNR, 24/7 Support).
- Passenger testimonials and corporate footer.

### 2. Login Page (`/login`)
- Email & password input with show/hide password toggle.
- "Remember me" session persistence.
- Auto-fill demo credentials button for quick examination evaluation.
- "Forgot Password?" interactive demo modal.
- JWT token generation and automated redirection.

### 3. Signup / Registration Page (`/signup`)
- Full Name, Email, Phone Number, Date of Birth, Gender, Password, Confirm Password.
- Terms and Conditions agreement checkbox.
- Password strength and match validation.
- Secure Bcrypt password hashing prior to MongoDB insertion.

### 4. Flight Search & Details Page (`/flights`)
- Interactive flight search modification banner.
- Sidebar filters: Airline filter (Air India, IndiGo, SpiceJet, Vistara, Akasa, Emirates), Travel Class (Economy/Business), Price range slider (₹2,000 - ₹50,000+).
- Sorting options: Price Low to High, Price High to Low, Departure Time, Duration.
- Flight result cards with airline badges, departure/arrival airport codes, flight timeline, available seat indicator, and "Book Now" CTA.

### 5. Passenger Details Page (`/booking/:flightId`)
- Flight overview summary banner.
- Dynamic multi-passenger forms generated according to the selected passenger count.
- Lead passenger contact information & adult identity verification.
- Sticky Fare Summary with Base Fare, 12% GST Taxes, Convenience Fee, and Grand Total.

### 6. Payment Page (`/payment`)
- Review booking and passenger summary.
- 3 Demo Payment Gateways:
  1. **Credit / Debit Card**: Formatted 16-digit card input, MM/YY expiry, CVV masking.
  2. **UPI / QR Code**: Interactive QR code scanning simulator and UPI ID input (`username@bank`).
  3. **Net Banking**: Bank selectors for HDFC, SBI, ICICI, Axis, Kotak.
- Animated payment authorization state.
- Automated creation of Booking and Payment records in MongoDB, seat inventory deduction, and PNR generation.

### 7. Booking Confirmation & My Bookings Page (`/confirmation/:id` & `/my-bookings`)
- **Booking Confirmation**: Success checkmark banner, unique PNR, electronic Boarding Pass with barcode, terminal/gate guidance, and "Print / Download PDF" action (`window.print()`).
- **My Bookings**: Filterable list (All, Confirmed, Cancelled) of all past and upcoming flights for the logged-in user with instant "View Ticket" and "Cancel Booking" with automated seat refund.

---

## 🗄️ MongoDB Database Design

### 1. Users Collection (`users`)
- `_id`: ObjectId
- `fullName`: String
- `email`: String (Unique, Lowercase)
- `phone`: String
- `dateOfBirth`: Date
- `gender`: String ('Male', 'Female', 'Other')
- `password`: String (Bcrypt hashed)
- `createdAt`: Date

### 2. Flights Collection (`flights`)
- `_id`: ObjectId
- `airline`: String (e.g. 'Air India', 'IndiGo', 'Emirates')
- `flightNumber`: String (e.g. 'AI-887', '6E-2041')
- `from`: String (e.g. 'Mumbai (BOM)')
- `to`: String (e.g. 'Delhi (DEL)')
- `departureDate`: Date
- `departureTime`: String (e.g. '06:00 AM')
- `arrivalTime`: String (e.g. '08:15 AM')
- `duration`: String (e.g. '2h 15m')
- `class`: String ('Economy', 'Business')
- `price`: Number
- `totalSeats`: Number
- `availableSeats`: Number
- `status`: String ('On Time', 'Delayed', 'Cancelled')

### 3. Bookings Collection (`bookings`)
- `_id`: ObjectId
- `bookingId`: String (Unique PNR, e.g. 'SW-784920')
- `userId`: ObjectId (Ref: User)
- `flightId`: ObjectId (Ref: Flight)
- `passengers`: Array of objects (`fullName`, `gender`, `dateOfBirth`, `passportOrId`, `email`, `phone`, `seatNumber`)
- `numberOfPassengers`: Number
- `travelClass`: String ('Economy', 'Business')
- `baseFare`: Number
- `taxes`: Number
- `serviceCharges`: Number
- `totalAmount`: Number
- `bookingStatus`: String ('Confirmed', 'Cancelled', 'Completed')
- `paymentStatus`: String ('Pending', 'Successful', 'Failed')
- `createdAt`: Date

### 4. Payments Collection (`payments`)
- `_id`: ObjectId
- `bookingId`: ObjectId (Ref: Booking)
- `userId`: ObjectId (Ref: User)
- `amount`: Number
- `paymentMethod`: String ('Credit Card', 'Debit Card', 'UPI', 'Net Banking')
- `paymentStatus`: String ('Successful', 'Pending', 'Failed')
- `transactionId`: String (e.g. 'TXN-982314562')
- `cardLast4`: String
- `createdAt`: Date

*(Note: Sensitive CVV and plain card credentials are never stored in MongoDB.)*

---

## 🚀 Installation & Setup Guide

### Prerequisites
- [Node.js](https://nodejs.org/) (v16+ or v18+ recommended)
- [MongoDB](https://www.mongodb.com/) (Optional: if local MongoDB is not running, the system automatically runs an embedded in-memory MongoDB server for zero-configuration testing!)

---

### Step 1: Backend Installation & Setup

Open your terminal, navigate to the `backend` directory:

```bash
cd backend
npm install
```

Create a `.env` file in the `backend` directory (or copy from `.env.example`):

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/airline_booking
JWT_SECRET=skywings_secret_jwt_key_2026_super_secure
NODE_ENV=development
```

#### Populate Sample Flight & Demo User Data:
```bash
npm run seed
```

#### Start the Backend Server:
```bash
npm start
```
*(Backend API will run on `http://localhost:5000`)*

---

### Step 2: Frontend Installation & Setup

Open a second terminal, navigate to the `frontend` directory:

```bash
cd frontend
npm install
```

#### Start the React Frontend:
```bash
npm run dev
```
*(Frontend application will launch at `http://localhost:3000`)*

---

## 🔑 Demo Test User Credentials

| Field | Value |
|---|---|
| **Email** | `demo@skywings.com` |
| **Password** | `password123` |
| **Role** | Verified Passenger |

*(You can also click the **"Auto-fill Demo Credentials"** button on the Login page for 1-click evaluation.)*

---

## 📡 REST API Reference

### Authentication
- `POST /api/auth/signup` - Register a new passenger account
- `POST /api/auth/login` - Authenticate and retrieve JWT token
- `GET /api/auth/profile` - Get logged-in user profile (Protected)

### Flights
- `GET /api/flights` - Get flights with optional query filters (`from`, `to`, `class`, `airline`, `maxPrice`, `sort`)
- `POST /api/flights/search` - Advanced flight search endpoint
- `GET /api/flights/featured` - Get top featured flight deals
- `GET /api/flights/:id` - Get single flight details by ID

### Bookings (Protected)
- `POST /api/bookings` - Create new flight booking and deduct available seats
- `GET /api/bookings` - Get all bookings for authenticated user
- `GET /api/bookings/:id` - Get booking details by ID or PNR
- `PUT /api/bookings/:id/cancel` - Cancel booking and restore flight seats

### Payments (Protected)
- `POST /api/payments` - Process demo payment and record transaction ID
- `GET /api/payments/:bookingId` - Get payment details for a booking

---

## 📁 Project Directory Structure

```
airline-booking-system/
├── backend/
│   ├── config/
│   │   └── db.js                 # MongoDB connection & in-memory fallback
│   ├── controllers/
│   │   ├── authController.js     # Signup, Login, Profile
│   │   ├── flightController.js   # Flight Search, Filters, Details
│   │   ├── bookingController.js  # Booking creation, history & cancellation
│   │   └── paymentController.js  # Demo payment processing
│   ├── middleware/
│   │   ├── authMiddleware.js     # JWT token verification guard
│   │   └── errorMiddleware.js    # Express error handler
│   ├── models/
│   │   ├── User.js               # User Schema with Bcrypt
│   │   ├── Flight.js             # Flight Schema with seat inventory
│   │   ├── Booking.js            # Booking Schema with PNR
│   │   └── Payment.js            # Payment Schema with TXN ID
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── flightRoutes.js
│   │   ├── bookingRoutes.js
│   │   └── paymentRoutes.js
│   ├── seed.js                   # Seed script with 20+ realistic flights
│   ├── server.js                 # Express server entry point
│   ├── .env
│   ├── .env.example
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx        # Navigation bar with user profile dropdown
│   │   │   ├── Footer.jsx        # Responsive corporate footer
│   │   │   ├── FlightCard.jsx    # Flight card with route line & pricing
│   │   │   ├── SearchForm.jsx    # Hero flight search form
│   │   │   ├── BookingSummary.jsx# Fare breakdown summary
│   │   │   ├── PassengerForm.jsx # Dynamic multi-passenger forms
│   │   │   ├── PaymentForm.jsx   # Card, UPI & Net Banking tabs
│   │   │   ├── TicketView.jsx    # Boarding Pass & Printable ticket
│   │   │   ├── LoadingSpinner.jsx# Loading spinner
│   │   │   ├── AlertMessage.jsx  # Alerts & toasts
│   │   │   └── ProtectedRoute.jsx# Auth route guard
│   │   ├── context/
│   │   │   ├── AuthContext.jsx   # Authentication context & session
│   │   │   └── BookingContext.jsx# Active search & booking state
│   │   ├── pages/
│   │   │   ├── HomePage.jsx               # Page 1: Home
│   │   │   ├── LoginPage.jsx              # Page 2: Login
│   │   │   ├── SignupPage.jsx             # Page 3: Signup
│   │   │   ├── FlightSearchPage.jsx       # Page 4: Search & Filters
│   │   │   ├── PassengerDetailsPage.jsx   # Page 5: Passenger details
│   │   │   ├── PaymentPage.jsx            # Page 6: Demo Payment
│   │   │   ├── BookingConfirmationPage.jsx# Page 7A: Boarding pass
│   │   │   └── MyBookingsPage.jsx         # Page 7B: My Bookings
│   │   ├── services/
│   │   │   ├── api.js            # Axios with Bearer token interceptor
│   │   │   ├── authService.js
│   │   │   ├── flightService.js
│   │   │   ├── bookingService.js
│   │   │   └── paymentService.js
│   │   ├── App.jsx               # Routes setup
│   │   ├── index.css             # Aviation styles & print stylesheet
│   │   └── main.jsx
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
│
└── README.md
```

---

## 🎓 College Examination Evaluation Checklist

- [x] **Tech Stack Adherence**: Pure HTML5 + CSS3 + Bootstrap 5 + JavaScript + React.js + Node.js + Express.js + MongoDB.
- [x] **7 Distinct Pages**: All 7 required pages fully developed and seamlessly integrated with React Router.
- [x] **Real-world User Flow**: Home → Search → Select Flight → Passenger Details → Demo Payment → Instant PNR Boarding Pass → My Bookings.
- [x] **User Authentication**: Secure Bcrypt password hashing and JWT token storage with protected API routes.
- [x] **Responsive Design**: Mobile, tablet, and desktop friendly with Bootstrap 5 grid and navbar toggles.
- [x] **Live Data & Seed Script**: 20+ realistic routes with varying airlines, times, and classes.
- [x] **Zero Configuration Testing**: Embedded MongoDB memory server fallback if local MongoDB service is not running.
- [x] **Print / PDF Boarding Pass**: Dedicated printable ticket CSS layout for examiners to test printing.
