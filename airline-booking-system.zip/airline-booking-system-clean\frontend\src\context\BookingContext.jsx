import React, { createContext, useState, useContext } from 'react';

const BookingContext = createContext();

const initialSearchState = {
  from: 'Mumbai (BOM)',
  to: 'Delhi (DEL)',
  departureDate: new Date().toISOString().split('T')[0],
  returnDate: '',
  passengers: 1,
  travelClass: 'Economy',
  tripType: 'one-way'
};

export const BookingProvider = ({ children }) => {
  const [searchParams, setSearchParams] = useState(initialSearchState);
  const [selectedFlight, setSelectedFlight] = useState(null);
  const [passengersData, setPassengersData] = useState([]);
  const [currentBooking, setCurrentBooking] = useState(null);

  const updateSearch = (newParams) => {
    setSearchParams((prev) => ({ ...prev, ...newParams }));
  };

  const clearBookingDraft = () => {
    setSelectedFlight(null);
    setPassengersData([]);
    setCurrentBooking(null);
  };

  return (
    <BookingContext.Provider
      value={{
        searchParams,
        updateSearch,
        selectedFlight,
        setSelectedFlight,
        passengersData,
        setPassengersData,
        currentBooking,
        setCurrentBooking,
        clearBookingDraft
      }}
    >
      {children}
    </BookingContext.Provider>
  );
};

export const useBooking = () => {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error('useBooking must be used within a BookingProvider');
  }
  return context;
};
