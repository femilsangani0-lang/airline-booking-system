import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import SearchForm from '../components/SearchForm';
import FlightCard from '../components/FlightCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { flightService } from '../services/flightService';
import { useBooking } from '../context/BookingContext';

const airlinesList = ['Air India', 'IndiGo', 'SpiceJet', 'Vistara', 'Akasa Air', 'Emirates'];

const FlightSearchPage = () => {
  const [urlParams] = useSearchParams();
  const { searchParams } = useBooking();

  const [flights, setFlights] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters State
  const [selectedAirline, setSelectedAirline] = useState('All');
  const [selectedClass, setSelectedClass] = useState('All');
  const [maxPrice, setMaxPrice] = useState(50000);
  const [sortBy, setSortBy] = useState('price_asc');

  useEffect(() => {
    const fetchSearchResults = async () => {
      setLoading(true);
      try {
        const fromQuery = urlParams.get('from') || searchParams.from || '';
        const toQuery = urlParams.get('to') || searchParams.to || '';

        const res = await flightService.searchFlights({
          from: fromQuery.split('(')[0].trim(),
          to: toQuery.split('(')[0].trim(),
          departureDate: searchParams.departureDate,
          travelClass: selectedClass !== 'All' ? selectedClass : searchParams.travelClass,
          airline: selectedAirline !== 'All' ? selectedAirline : '',
          maxPrice: maxPrice < 50000 ? maxPrice : undefined,
          sort: sortBy
        });

        if (res.success && res.data) {
          setFlights(res.data);
        }
      } catch (err) {
        console.error('Error fetching search flights:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchSearchResults();
  }, [urlParams, searchParams, selectedAirline, selectedClass, maxPrice, sortBy]);

  const handleResetFilters = () => {
    setSelectedAirline('All');
    setSelectedClass('All');
    setMaxPrice(50000);
    setSortBy('price_asc');
  };

  return (
    <div className="py-4 bg-light">
      <div className="container">
        {/* Modify Search Bar */}
        <div className="mb-4">
          <SearchForm />
        </div>

        <div className="row g-4">
          {/* Sidebar Filters */}
          <div className="col-12 col-lg-3">
            <div className="card border-0 shadow-sm rounded-4 p-3 p-md-4 sticky-top" style={{ top: '85px' }}>
              <div className="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                <h6 className="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                  <i className="bi bi-funnel-fill text-primary"></i> Filter Flights
                </h6>
                <button className="btn btn-link p-0 small text-decoration-none" onClick={handleResetFilters}>
                  Reset All
                </button>
              </div>

              {/* Filter: Travel Class */}
              <div className="mb-4">
                <label className="small fw-bold text-secondary mb-2">Cabin Class</label>
                <div className="d-flex flex-column gap-2">
                  {['All', 'Economy', 'Business'].map((cls) => (
                    <div key={cls} className="form-check">
                      <input
                        className="form-check-input"
                        type="radio"
                        name="classFilter"
                        id={`class_${cls}`}
                        checked={selectedClass === cls}
                        onChange={() => setSelectedClass(cls)}
                      />
                      <label className="form-check-label small" htmlFor={`class_${cls}`}>
                        {cls === 'All' ? 'All Classes' : cls}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Filter: Airline */}
              <div className="mb-4">
                <label className="small fw-bold text-secondary mb-2">Airlines</label>
                <select
                  className="form-select form-select-sm"
                  value={selectedAirline}
                  onChange={(e) => setSelectedAirline(e.target.value)}
                >
                  <option value="All">All Airlines</option>
                  {airlinesList.map((airline) => (
                    <option key={airline} value={airline}>
                      {airline}
                    </option>
                  ))}
                </select>
              </div>

              {/* Filter: Max Price Slider */}
              <div className="mb-3">
                <div className="d-flex justify-content-between align-items-center mb-1">
                  <label className="small fw-bold text-secondary">Max Budget</label>
                  <span className="small fw-bold text-primary">₹{maxPrice.toLocaleString('en-IN')}</span>
                </div>
                <input
                  type="range"
                  className="form-range"
                  min="2000"
                  max="50000"
                  step="500"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Number(e.target.value))}
                />
                <div className="d-flex justify-content-between small text-muted">
                  <span>₹2,000</span>
                  <span>₹50,000+</span>
                </div>
              </div>
            </div>
          </div>

          {/* Results List */}
          <div className="col-12 col-lg-9">
            {/* Header: Count & Sorting */}
            <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3 bg-white p-3 rounded-4 shadow-sm">
              <div>
                <h5 className="mb-0 fw-bold text-dark">
                  Available Flights
                </h5>
                <small className="text-muted">
                  Showing {flights.length} flights for {searchParams.from.split('(')[0]} → {searchParams.to.split('(')[0]}
                </small>
              </div>

              <div className="d-flex align-items-center gap-2">
                <label className="small text-muted fw-bold text-nowrap">Sort By:</label>
                <select
                  className="form-select form-select-sm rounded-pill fw-medium"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  style={{ minWidth: '180px' }}
                >
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                  <option value="departure_time">Departure Time</option>
                  <option value="duration">Flight Duration</option>
                </select>
              </div>
            </div>

            {/* Results Rendering */}
            {loading ? (
              <LoadingSpinner message="Searching available flights in real-time..." />
            ) : flights.length > 0 ? (
              flights.map((flight) => (
                <FlightCard key={flight._id} flight={flight} />
              ))
            ) : (
              <div className="card border-0 shadow-sm rounded-4 p-5 text-center bg-white">
                <div className="bg-light rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style={{ width: '64px', height: '64px' }}>
                  <i className="bi bi-airplane text-muted fs-3"></i>
                </div>
                <h5 className="fw-bold text-dark">No Flights Found</h5>
                <p className="text-muted small mx-auto" style={{ maxWidth: '400px' }}>
                  We couldn't find any flights matching your exact filter criteria. Try adjusting your filters or price range.
                </p>
                <div>
                  <button className="btn btn-outline-primary rounded-pill px-4" onClick={handleResetFilters}>
                    Reset All Filters
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FlightSearchPage;
