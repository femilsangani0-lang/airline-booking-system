import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { bookingService } from '../services/bookingService';
import LoadingSpinner from '../components/LoadingSpinner';
import AlertMessage from '../components/AlertMessage';
import TicketView from '../components/TicketView';

const MyBookingsPage = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');

  // Selected Booking for Modal Boarding Pass View
  const [activeTicket, setActiveTicket] = useState(null);

  // Modal for Cancel Confirmation
  const [cancelModalBooking, setCancelModalBooking] = useState(null);
  const [cancelling, setCancelling] = useState(false);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const res = await bookingService.getUserBookings();
      if (res.success && res.data) {
        setBookings(res.data);
      }
    } catch (err) {
      setError('Failed to retrieve your bookings. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleCancelBooking = async () => {
    if (!cancelModalBooking) return;
    setCancelling(true);
    setError('');
    try {
      const res = await bookingService.cancelBooking(cancelModalBooking._id);
      if (res.success) {
        setSuccessMsg(`Booking ${cancelModalBooking.bookingId} was successfully cancelled.`);
        setCancelModalBooking(null);
        fetchBookings(); // refresh list
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to cancel booking.');
    } finally {
      setCancelling(false);
    }
  };

  const filteredBookings = bookings.filter((b) => {
    if (filterStatus === 'All') return true;
    return b.bookingStatus === filterStatus;
  });

  return (
    <div className="py-4 bg-light">
      <div className="container">
        {/* Page Header */}
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
          <div>
            <h3 className="fw-bold text-dark mb-1">My Flight Bookings</h3>
            <p className="text-muted small mb-0">Manage your upcoming journeys, view boarding passes, and download e-tickets.</p>
          </div>

          <Link to="/flights" className="btn btn-primary rounded-pill px-4 fw-semibold">
            <i className="bi bi-plus-lg me-1"></i> Book New Flight
          </Link>
        </div>

        <AlertMessage message={error} onClose={() => setError('')} />
        <AlertMessage type="success" message={successMsg} onClose={() => setSuccessMsg('')} />

        {/* Filter Tabs */}
        <div className="bg-white p-2 rounded-4 shadow-sm mb-4 d-inline-flex gap-1 border">
          {['All', 'Confirmed', 'Cancelled'].map((tab) => (
            <button
              key={tab}
              className={`btn btn-sm rounded-pill px-3 fw-semibold ${filterStatus === tab ? 'btn-primary' : 'btn-light text-muted'}`}
              onClick={() => setFilterStatus(tab)}
            >
              {tab} ({bookings.filter(b => tab === 'All' ? true : b.bookingStatus === tab).length})
            </button>
          ))}
        </div>

        {/* Bookings List */}
        {loading ? (
          <LoadingSpinner message="Fetching your past and upcoming bookings..." />
        ) : filteredBookings.length > 0 ? (
          <div className="d-flex flex-column gap-3">
            {filteredBookings.map((b) => (
              <div key={b._id} className="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                <div className="card-header bg-light py-3 px-4 d-flex justify-content-between align-items-center flex-wrap gap-2">
                  <div className="d-flex align-items-center gap-2">
                    <span className="small text-muted">PNR:</span>
                    <span className="fw-bold text-primary font-monospace">{b.bookingId}</span>
                    <span className={`badge ${b.bookingStatus === 'Confirmed' ? 'bg-success' : 'bg-danger'} ms-2`}>
                      {b.bookingStatus}
                    </span>
                  </div>
                  <span className="small text-muted">
                    Booked on {new Date(b.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </span>
                </div>

                <div className="card-body p-4">
                  <div className="row align-items-center g-3">
                    {/* Airline & Route */}
                    <div className="col-12 col-md-5">
                      <div className="d-flex align-items-center gap-3">
                        <div className="bg-primary-subtle text-primary p-2 rounded-3">
                          <i className="bi bi-airplane-fill fs-4"></i>
                        </div>
                        <div>
                          <h6 className="mb-0 fw-bold text-dark">{b.flightId?.airline || 'SkyWings'} ({b.flightId?.flightNumber || 'SW-101'})</h6>
                          <div className="small text-muted mt-1">
                            <span className="fw-semibold text-dark">{b.flightId?.from}</span> → <span className="fw-semibold text-dark">{b.flightId?.to}</span>
                          </div>
                          <div className="small text-secondary mt-1">
                            {b.numberOfPassengers} Passenger(s) • <span className="badge bg-light text-secondary border">{b.travelClass}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Timing */}
                    <div className="col-12 col-md-4 text-md-center">
                      <div className="small text-muted">Departure Time</div>
                      <h5 className="mb-0 fw-bold text-dark">{b.flightId?.departureTime}</h5>
                      <span className="small text-muted">{b.flightId?.duration} • Non-stop</span>
                    </div>

                    {/* Fare & Actions */}
                    <div className="col-12 col-md-3 text-md-end">
                      <div className="small text-muted">Total Paid</div>
                      <h5 className="fw-bold text-success mb-2">₹{b.totalAmount?.toLocaleString('en-IN')}</h5>

                      <div className="d-flex flex-md-column gap-2 justify-content-end">
                        <button
                          className="btn btn-outline-primary btn-sm rounded-pill fw-semibold"
                          onClick={() => setActiveTicket(b)}
                        >
                          <i className="bi bi-ticket-detailed me-1"></i> View Ticket
                        </button>

                        {b.bookingStatus === 'Confirmed' && (
                          <button
                            className="btn btn-outline-danger btn-sm rounded-pill fw-semibold"
                            onClick={() => setCancelModalBooking(b)}
                          >
                            <i className="bi bi-x-circle me-1"></i> Cancel Booking
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card border-0 shadow-sm rounded-4 p-5 text-center bg-white">
            <div className="bg-light rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style={{ width: '64px', height: '64px' }}>
              <i className="bi bi-ticket-perforated text-muted fs-3"></i>
            </div>
            <h5 className="fw-bold text-dark">No Bookings Found</h5>
            <p className="text-muted small mx-auto" style={{ maxWidth: '400px' }}>
              {filterStatus === 'All'
                ? "You haven't made any flight bookings yet. Search flights to book your next trip!"
                : `You don't have any ${filterStatus.toLowerCase()} flight bookings.`}
            </p>
            <div>
              <Link to="/flights" className="btn btn-primary rounded-pill px-4">Search Flights Now</Link>
            </div>
          </div>
        )}
      </div>

      {/* Ticket Modal */}
      {activeTicket && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.6)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div className="modal-content rounded-4 border-0">
              <div className="modal-header border-0 pb-0">
                <h5 className="modal-title fw-bold">Electronic Ticket & Boarding Pass</h5>
                <button type="button" className="btn-close" onClick={() => setActiveTicket(null)}></button>
              </div>
              <div className="modal-body p-4">
                <TicketView booking={activeTicket} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Confirmation Modal */}
      {cancelModalBooking && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.6)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content rounded-4 border-0">
              <div className="modal-header border-0 pb-0">
                <h5 className="modal-title fw-bold text-danger">Cancel Flight Booking?</h5>
                <button type="button" className="btn-close" onClick={() => setCancelModalBooking(null)}></button>
              </div>
              <div className="modal-body p-4">
                <p className="text-dark">
                  Are you sure you want to cancel booking <strong>{cancelModalBooking.bookingId}</strong> for flight <strong>{cancelModalBooking.flightId?.airline} ({cancelModalBooking.flightId?.flightNumber})</strong>?
                </p>
                <div className="alert alert-warning small mb-0">
                  <i className="bi bi-exclamation-triangle-fill me-1"></i>
                  Upon cancellation, a full refund of <strong>₹{cancelModalBooking.totalAmount?.toLocaleString('en-IN')}</strong> will be credited to the original payment method and seats will be released.
                </div>
              </div>
              <div className="modal-footer border-0 pt-0">
                <button type="button" className="btn btn-light rounded-pill px-4" onClick={() => setCancelModalBooking(null)}>
                  Keep Booking
                </button>
                <button
                  type="button"
                  className="btn btn-danger rounded-pill px-4 fw-semibold"
                  onClick={handleCancelBooking}
                  disabled={cancelling}
                >
                  {cancelling ? 'Cancelling...' : 'Yes, Cancel Flight'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MyBookingsPage;
