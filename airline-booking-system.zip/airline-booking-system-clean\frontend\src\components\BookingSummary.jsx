import React from 'react';

const BookingSummary = ({ flight, numberOfPassengers = 1, showPromo = true }) => {
  if (!flight) return null;

  const baseFare = flight.price * numberOfPassengers;
  const taxes = Math.round(baseFare * 0.12);
  const serviceCharges = 150;
  const grandTotal = baseFare + taxes + serviceCharges;

  return (
    <div className="card border-0 shadow-sm rounded-4 overflow-hidden sticky-top" style={{ top: '90px' }}>
      <div className="card-header text-white py-3" style={{ backgroundColor: '#0b1f44' }}>
        <h6 className="mb-0 fw-bold d-flex align-items-center gap-2">
          <i className="bi bi-receipt-cutoff text-primary"></i> Fare Summary
        </h6>
      </div>

      <div className="card-body p-4">
        <div className="pb-3 mb-3 border-bottom">
          <div className="d-flex justify-content-between align-items-center mb-1">
            <span className="fw-bold text-dark">{flight.airline}</span>
            <span className="badge bg-primary-subtle text-primary">{flight.flightNumber}</span>
          </div>
          <div className="small text-muted d-flex justify-content-between">
            <span>{flight.from.split('(')[0]} → {flight.to.split('(')[0]}</span>
            <span className="fw-semibold text-dark">{flight.class}</span>
          </div>
        </div>

        <div className="d-flex flex-column gap-2 small">
          <div className="d-flex justify-content-between text-secondary">
            <span>Base Fare ({numberOfPassengers} {numberOfPassengers > 1 ? 'Passengers' : 'Passenger'})</span>
            <span className="fw-semibold text-dark">₹{baseFare.toLocaleString('en-IN')}</span>
          </div>
          <div className="d-flex justify-content-between text-secondary">
            <span>Taxes & GST (12%)</span>
            <span className="fw-semibold text-dark">₹{taxes.toLocaleString('en-IN')}</span>
          </div>
          <div className="d-flex justify-content-between text-secondary">
            <span>Convenience & Aviation Fee</span>
            <span className="fw-semibold text-dark">₹{serviceCharges.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {showPromo && (
          <div className="my-3 pt-3 border-top">
            <div className="input-group input-group-sm">
              <input type="text" className="form-control" placeholder="Enter Promo Code" />
              <button className="btn btn-outline-primary fw-semibold" type="button">Apply</button>
            </div>
          </div>
        )}

        <hr className="my-3" />

        <div className="d-flex justify-content-between align-items-center">
          <div>
            <span className="text-muted small d-block">Grand Total</span>
            <span className="fw-bold fs-4 text-primary">₹{grandTotal.toLocaleString('en-IN')}</span>
          </div>
          <span className="badge bg-success-subtle text-success py-2 px-3 rounded-pill fw-semibold">
            <i className="bi bi-shield-check me-1"></i> Best Price
          </span>
        </div>
      </div>
    </div>
  );
};

export default BookingSummary;
