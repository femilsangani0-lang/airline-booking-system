import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { flightService } from '../services/flightService';
import { useBooking } from '../context/BookingContext';
import { useAuth } from '../context/AuthContext';
import PassengerForm from '../components/PassengerForm';
import BookingSummary from '../components/BookingSummary';
import LoadingSpinner from '../components/LoadingSpinner';
import AlertMessage from '../components/AlertMessage';

const PassengerDetailsPage = () => {
  const { flightId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { selectedFlight, setSelectedFlight, searchParams, passengersData, setPassengersData } = useBooking();

  const [flight, setFlight] = useState(selectedFlight);
  const [loading, setLoading] = useState(!selectedFlight);
  const [error, setError] = useState('');

  const count = searchParams.passengers || 1;

  // Initialize passenger list
  const [passengers, setPassengers] = useState(() => {
    if (passengersData && passengersData.length === count) {
      return passengersData;
    }
    const initialList = [];
    for (let i = 0; i < count; i++) {
      initialList.push({
        fullName: i === 0 && user?.fullName ? user.fullName : '',
        gender: i === 0 && user?.gender ? user.gender : 'Male',
        dateOfBirth: i === 0 && user?.dateOfBirth ? new Date(user.dateOfBirth).toISOString().split('T')[0] : '',
        passportOrId: '',
        email: i === 0 && user?.email ? user.email : '',
        phone: i === 0 && user?.phone ? user.phone : ''
      });
    }
    return initialList;
  });

  useEffect(() => {
    if (!flight && flightId) {
      const fetchFlight = async () => {
        try {
          const res = await flightService.getFlightById(flightId);
          if (res.success && res.data) {
            setFlight(res.data);
            setSelectedFlight(res.data);
          }
        } catch (err) {
          setError('Failed to load selected flight details.');
        } finally {
          setLoading(false);
        }
      };
      fetchFlight();
    }
  }, [flight, flightId, setSelectedFlight]);

  const handlePassengerChange = (index, updatedPassenger) => {
    const updated = [...passengers];
    updated[index] = updatedPassenger;
    setPassengers(updated);
  };

  const handleProceedToPayment = (e) => {
    e.preventDefault();
    setError('');

    // Validate all passenger entries
    for (let i = 0; i < passengers.length; i++) {
      const p = passengers[i];
      if (!p.fullName.trim()) {
        setError(`Please enter Full Name for Passenger ${i + 1}`);
        return;
      }
      if (!p.passportOrId.trim()) {
        setError(`Please enter Passport or ID Number for Passenger ${i + 1}`);
        return;
      }
      if (i === 0 && (!p.email || !p.phone)) {
        setError('Lead passenger must provide both email address and contact phone number');
        return;
      }
    }

    // Save into booking draft context
    setPassengersData(passengers);

    // Redirect to Payment page
    navigate('/payment');
  };

  if (loading) {
    return <LoadingSpinner message="Preparing passenger booking form..." />;
  }

  if (!flight) {
    return (
      <div className="container py-5 text-center">
        <h4>No flight selected</h4>
        <p className="text-muted">Please search and select an available flight first.</p>
        <Link to="/flights" className="btn btn-primary rounded-pill px-4">Search Flights</Link>
      </div>
    );
  }

  return (
    <div className="py-4 bg-light">
      <div className="container">
        {/* Breadcrumb / Step Indicator */}
        <div className="d-flex align-items-center gap-2 mb-4 small text-muted">
          <Link to="/" className="text-decoration-none text-muted">Home</Link>
          <i className="bi bi-chevron-right"></i>
          <Link to="/flights" className="text-decoration-none text-muted">Flight Search</Link>
          <i className="bi bi-chevron-right"></i>
          <span className="text-primary fw-bold">Passenger Details</span>
          <i className="bi bi-chevron-right"></i>
          <span>Payment</span>
        </div>

        <AlertMessage message={error} onClose={() => setError('')} />

        <div className="row g-4">
          {/* Passenger Form Inputs */}
          <div className="col-12 col-lg-8">
            {/* Flight Banner Overview */}
            <div className="card border-0 shadow-sm rounded-4 p-3 p-md-4 mb-4 bg-white">
              <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 pb-2 border-bottom">
                <div className="d-flex align-items-center gap-2">
                  <span className="badge bg-primary px-2 py-1">{flight.airline}</span>
                  <span className="fw-bold text-dark">{flight.flightNumber}</span>
                </div>
                <span className="badge bg-light text-dark border">{flight.class} Class</span>
              </div>

              <div className="row align-items-center text-center mt-3">
                <div className="col-4 text-start">
                  <h5 className="mb-0 fw-bold text-dark">{flight.departureTime}</h5>
                  <p className="mb-0 small text-muted fw-semibold">{flight.from}</p>
                </div>
                <div className="col-4">
                  <span className="small text-muted">{flight.duration}</span>
                  <div className="flight-route-line my-1">
                    <i className="bi bi-airplane-fill flight-route-plane"></i>
                  </div>
                  <span className="small text-success fw-bold">Non-Stop</span>
                </div>
                <div className="col-4 text-end">
                  <h5 className="mb-0 fw-bold text-dark">{flight.arrivalTime}</h5>
                  <p className="mb-0 small text-muted fw-semibold">{flight.to}</p>
                </div>
              </div>
            </div>

            {/* Dynamic Passenger Forms */}
            <form onSubmit={handleProceedToPayment}>
              {passengers.map((p, idx) => (
                <PassengerForm
                  key={idx}
                  index={idx}
                  passenger={p}
                  onChange={handlePassengerChange}
                  isLead={idx === 0}
                />
              ))}

              <div className="d-flex justify-content-between align-items-center mt-4">
                <Link to="/flights" className="btn btn-outline-secondary px-4 py-2 rounded-pill fw-semibold">
                  <i className="bi bi-arrow-left me-1"></i> Back to Flights
                </Link>

                <button type="submit" className="btn btn-primary px-5 py-3 rounded-pill fw-bold fs-6 shadow">
                  Proceed to Payment <i className="bi bi-arrow-right ms-2"></i>
                </button>
              </div>
            </form>
          </div>

          {/* Sticky Fare Summary */}
          <div className="col-12 col-lg-4">
            <BookingSummary flight={flight} numberOfPassengers={count} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PassengerDetailsPage;
