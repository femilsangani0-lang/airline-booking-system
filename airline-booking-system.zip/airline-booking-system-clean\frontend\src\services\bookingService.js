import API from './api';

export const bookingService = {
  createBooking: async (bookingData) => {
    const response = await API.post('/bookings', bookingData);
    return response.data;
  },
  getUserBookings: async () => {
    const response = await API.get('/bookings');
    return response.data;
  },
  getBookingById: async (id) => {
    const response = await API.get(`/bookings/${id}`);
    return response.data;
  },
  cancelBooking: async (id) => {
    const response = await API.put(`/bookings/${id}/cancel`);
    return response.data;
  }
};
