const mongoose = require('mongoose');

const passengerSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: [true, 'Passenger full name is required'],
    trim: true
  },
  gender: {
    type: String,
    enum: ['Male', 'Female', 'Other'],
    required: [true, 'Gender is required']
  },
  dateOfBirth: {
    type: Date,
    required: [true, 'Date of birth is required']
  },
  passportOrId: {
    type: String,
    required: [true, 'Passport or Government ID number is required'],
    trim: true
  },
  email: {
    type: String,
    trim: true
  },
  phone: {
    type: String,
    trim: true
  },
  seatNumber: {
    type: String,
    default: 'Unassigned'
  }
});

const bookingSchema = new mongoose.Schema({
  bookingId: {
    type: String,
    required: true,
    unique: true,
    uppercase: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  flightId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Flight',
    required: true
  },
  passengers: [passengerSchema],
  numberOfPassengers: {
    type: Number,
    required: true,
    min: 1
  },
  travelClass: {
    type: String,
    enum: ['Economy', 'Business'],
    default: 'Economy'
  },
  baseFare: {
    type: Number,
    required: true
  },
  taxes: {
    type: Number,
    required: true
  },
  serviceCharges: {
    type: Number,
    default: 150
  },
  totalAmount: {
    type: Number,
    required: true
  },
  bookingStatus: {
    type: String,
    enum: ['Confirmed', 'Cancelled', 'Completed'],
    default: 'Confirmed'
  },
  paymentStatus: {
    type: String,
    enum: ['Pending', 'Successful', 'Failed'],
    default: 'Successful'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Booking', bookingSchema);
