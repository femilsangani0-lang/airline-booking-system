import axios from 'axios';

const API = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Interceptor to attach Authorization Bearer token to outgoing requests
API.interceptors.request.use(
  (config) => {
    const user = JSON.parse(localStorage.getItem('skywings_user') || 'null');
    if (user && user.token) {
      config.headers.Authorization = `Bearer ${user.token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Interceptor to handle global errors (e.g. 401 unauth)
API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      // Don't auto-redirect on login or signup failures
      if (!error.config.url.includes('/auth/login') && !error.config.url.includes('/auth/signup')) {
        localStorage.removeItem('skywings_user');
      }
    }
    return Promise.reject(error);
  }
);

export default API;
