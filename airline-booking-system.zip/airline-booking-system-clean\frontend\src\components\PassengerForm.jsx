import React from 'react';

const PassengerForm = ({ index, passenger, onChange, isLead = false }) => {
  const handleChange = (field, value) => {
    onChange(index, { ...passenger, [field]: value });
  };

  return (
    <div className="card border-0 shadow-sm rounded-4 mb-4">
      <div className="card-header bg-light py-3 px-4 d-flex justify-content-between align-items-center">
        <h6 className="mb-0 fw-bold text-dark d-flex align-items-center gap-2">
          <div className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style={{ width: '24px', height: '24px', fontSize: '0.8rem' }}>
            {index + 1}
          </div>
          Passenger {index + 1} {isLead && <span className="badge bg-primary-subtle text-primary ms-1 small">Lead Passenger</span>}
        </h6>
        <span className="badge bg-secondary-subtle text-secondary small">
          <i className="bi bi-person-badge me-1"></i> Adult
        </span>
      </div>

      <div className="card-body p-4">
        <div className="row g-3">
          <div className="col-12 col-md-6">
            <label className="form-label small fw-bold text-secondary">
              Full Name (as per Govt ID) <span className="text-danger">*</span>
            </label>
            <input
              type="text"
              className="form-control"
              placeholder="e.g. Rahul Sharma"
              value={passenger.fullName || ''}
              onChange={(e) => handleChange('fullName', e.target.value)}
              required
            />
          </div>

          <div className="col-6 col-md-3">
            <label className="form-label small fw-bold text-secondary">
              Gender <span className="text-danger">*</span>
            </label>
            <select
              className="form-select"
              value={passenger.gender || 'Male'}
              onChange={(e) => handleChange('gender', e.target.value)}
              required
            >
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div className="col-6 col-md-3">
            <label className="form-label small fw-bold text-secondary">
              Date of Birth <span className="text-danger">*</span>
            </label>
            <input
              type="date"
              className="form-control"
              max={new Date().toISOString().split('T')[0]}
              value={passenger.dateOfBirth || ''}
              onChange={(e) => handleChange('dateOfBirth', e.target.value)}
              required
            />
          </div>

          <div className="col-12 col-md-4">
            <label className="form-label small fw-bold text-secondary">
              Passport / Aadhaar Number <span className="text-danger">*</span>
            </label>
            <input
              type="text"
              className="form-control"
              placeholder="e.g. Z9876543 or Aadhaar"
              value={passenger.passportOrId || ''}
              onChange={(e) => handleChange('passportOrId', e.target.value)}
              required
            />
          </div>

          <div className="col-12 col-md-4">
            <label className="form-label small fw-bold text-secondary">
              Email Address {isLead && <span className="text-danger">*</span>}
            </label>
            <input
              type="email"
              className="form-control"
              placeholder="rahul@example.com"
              value={passenger.email || ''}
              onChange={(e) => handleChange('email', e.target.value)}
              required={isLead}
            />
          </div>

          <div className="col-12 col-md-4">
            <label className="form-label small fw-bold text-secondary">
              Phone Number {isLead && <span className="text-danger">*</span>}
            </label>
            <input
              type="tel"
              className="form-control"
              placeholder="9876543210"
              value={passenger.phone || ''}
              onChange={(e) => handleChange('phone', e.target.value)}
              required={isLead}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PassengerForm;
