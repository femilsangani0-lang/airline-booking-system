import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { bookingService } from '../services/bookingService';
import { useBooking } from '../context/BookingContext';
import TicketView from '../components/TicketView';
import LoadingSpinner from '../components/LoadingSpinner';

const BookingConfirmationPage = () => {
  const { id } = useParams();
  const { currentBooking } = useBooking();
  const [booking, setBooking] = useState(currentBooking);
  const [loading, setLoading] = useState(!currentBooking);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!booking && id) {
      const fetchBooking = async () => {
        try {
          const res = await bookingService.getBookingById(id);
          if (res.success && res.data) {
            setBooking(res.data);
          }
        } catch (err) {
          setError('Could not retrieve booking details.');
        } finally {
          setLoading(false);
        }
      };
      fetchBooking();
    }
  }, [booking, id]);

  if (loading) {
    return <LoadingSpinner message="Generating your electronic boarding pass..." />;
  }

  if (error || !booking) {
    return (
      <div className="container py-5 text-center">
        <h4 className="text-danger">Booking Not Found</h4>
        <p className="text-muted">{error || 'Could not locate booking records.'}</p>
        <Link to="/my-bookings" className="btn btn-primary rounded-pill px-4">Go to My Bookings</Link>
      </div>
    );
  }

  return (
    <div className="py-4 bg-light">
      <div className="container">
        {/* Success Banner */}
        <div className="card border-0 shadow-sm rounded-4 p-4 p-md-5 mb-4 text-center bg-white no-print">
          <div className="bg-success text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style={{ width: '64px', height: '64px' }}>
            <i className="bi bi-check-lg fs-1"></i>
          </div>
          <h2 className="fw-bold text-dark mb-1">Booking Confirmed!</h2>
          <p className="text-muted mb-3">
            Thank you for flying with SkyWings. Your flight reservation is confirmed and your tickets are issued.
          </p>

          <div className="d-inline-flex align-items-center gap-2 bg-light px-4 py-2 rounded-pill border">
            <span className="small text-muted fw-bold">PNR NUMBER:</span>
            <span className="fw-bold text-primary fs-5">{booking.bookingId}</span>
          </div>

          <div className="d-flex justify-content-center gap-3 mt-4">
            <button className="btn btn-primary rounded-pill px-4 fw-semibold" onClick={() => window.print()}>
              <i className="bi bi-printer-fill me-2"></i> Print / Download Ticket
            </button>
            <Link to="/my-bookings" className="btn btn-outline-secondary rounded-pill px-4 fw-semibold">
              <i className="bi bi-ticket-perforated me-2"></i> View All Bookings
            </Link>
          </div>
        </div>

        {/* Boarding Pass Component */}
        <TicketView booking={booking} />
      </div>
    </div>
  );
};

export default BookingConfirmationPage;
