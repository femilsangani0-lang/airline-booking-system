const mongoose = require('mongoose');

const flightSchema = new mongoose.Schema({
  airline: {
    type: String,
    required: [true, 'Airline name is required'],
    trim: true
  },
  flightNumber: {
    type: String,
    required: [true, 'Flight number is required'],
    unique: true,
    trim: true,
    uppercase: true
  },
  from: {
    type: String,
    required: [true, 'Departure airport/city is required'],
    trim: true
  },
  to: {
    type: String,
    required: [true, 'Arrival airport/city is required'],
    trim: true
  },
  departureDate: {
    type: Date,
    required: [true, 'Departure date is required']
  },
  departureTime: {
    type: String,
    required: [true, 'Departure time is required']
  },
  arrivalTime: {
    type: String,
    required: [true, 'Arrival time is required']
  },
  duration: {
    type: String,
    required: [true, 'Flight duration is required']
  },
  class: {
    type: String,
    enum: ['Economy', 'Business'],
    default: 'Economy'
  },
  price: {
    type: Number,
    required: [true, 'Ticket price is required']
  },
  totalSeats: {
    type: Number,
    required: [true, 'Total seats is required'],
    default: 180
  },
  availableSeats: {
    type: Number,
    required: [true, 'Available seats is required'],
    default: 180
  },
  status: {
    type: String,
    enum: ['On Time', 'Delayed', 'Cancelled'],
    default: 'On Time'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Flight', flightSchema);
