import React from 'react';

const TicketView = ({ booking }) => {
  if (!booking) return null;

  const { flightId: flight, passengers = [], bookingId, totalAmount, paymentStatus, bookingStatus, createdAt } = booking;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="printable-ticket">
      <div className="ticket-container mb-4">
        <div className="ticket-header d-flex justify-content-between align-items-center flex-wrap gap-2">
          <div className="d-flex align-items-center gap-2">
            <div className="bg-primary text-white rounded-3 p-1 d-flex align-items-center justify-content-center" style={{ width: '32px', height: '32px' }}>
              <i className="bi bi-airplane-fill fs-6"></i>
            </div>
            <div>
              <h5 className="mb-0 fw-bold">SkyWings Airlines</h5>
              <span className="small text-light opacity-75">Boarding Pass & E-Ticket</span>
            </div>
          </div>

          <div className="text-end">
            <div className="small text-light opacity-75">PNR / BOOKING ID</div>
            <h4 className="mb-0 fw-bold text-warning letter-spacing-1">{bookingId}</h4>
          </div>
        </div>

        <div className="ticket-body">
          <div className="row g-4">
            <div className="col-12 col-lg-8">
              <div className="d-flex justify-content-between align-items-center pb-3 border-bottom">
                <div>
                  <span className="small text-muted d-block">AIRLINE & FLIGHT</span>
                  <h6 className="mb-0 fw-bold text-dark">{flight?.airline || 'SkyWings'} ({flight?.flightNumber || 'SW-101'})</h6>
                </div>
                <div className="text-center">
                  <span className="small text-muted d-block">CLASS</span>
                  <span className="badge bg-primary-subtle text-primary fw-bold px-3 py-1">{booking.travelClass || flight?.class || 'Economy'}</span>
                </div>
                <div className="text-end">
                  <span className="small text-muted d-block">BOOKING STATUS</span>
                  <span className={`badge ${bookingStatus === 'Confirmed' ? 'bg-success' : 'bg-danger'} px-3 py-1`}>
                    {bookingStatus}
                  </span>
                </div>
              </div>

              <div className="row my-4 align-items-center">
                <div className="col-4">
                  <h3 className="fw-bold mb-0 text-dark">{flight?.departureTime || '06:00 AM'}</h3>
                  <h6 className="text-primary fw-bold mb-1">{flight?.from || 'Mumbai (BOM)'}</h6>
                  <span className="small text-muted">Terminal 2</span>
                </div>

                <div className="col-4 text-center">
                  <span className="small text-muted fw-semibold">{flight?.duration || '2h 15m'}</span>
                  <div className="flight-route-line my-1">
                    <i className="bi bi-airplane-fill flight-route-plane"></i>
                  </div>
                  <span className="small text-success fw-bold">Non-Stop</span>
                </div>

                <div className="col-4 text-end">
                  <h3 className="fw-bold mb-0 text-dark">{flight?.arrivalTime || '08:15 AM'}</h3>
                  <h6 className="text-primary fw-bold mb-1">{flight?.to || 'Delhi (DEL)'}</h6>
                  <span className="small text-muted">Terminal 3</span>
                </div>
              </div>

              <h6 className="fw-bold text-dark mb-2">Passenger Information</h6>
              <div className="table-responsive">
                <table className="table table-sm table-bordered align-middle">
                  <thead className="table-light small">
                    <tr>
                      <th>#</th>
                      <th>Passenger Name</th>
                      <th>Gender</th>
                      <th>ID / Passport</th>
                      <th>Seat</th>
                    </tr>
                  </thead>
                  <tbody>
                    {passengers.map((p, idx) => (
                      <tr key={idx}>
                        <td className="fw-bold">{idx + 1}</td>
                        <td className="fw-semibold text-dark">{p.fullName}</td>
                        <td>{p.gender}</td>
                        <td className="text-muted">{p.passportOrId}</td>
                        <td>
                          <span className="badge bg-warning text-dark fw-bold px-2 py-1">{p.seatNumber || `${idx + 12}B`}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="col-12 col-lg-4 border-start-lg">
              <div className="bg-light p-3 rounded-3 h-100 d-flex flex-column justify-content-between">
                <div>
                  <h6 className="fw-bold text-dark border-bottom pb-2 mb-3">Booking Summary</h6>
                  <div className="d-flex justify-content-between small mb-2">
                    <span className="text-muted">Total Paid:</span>
                    <span className="fw-bold text-success fs-6">₹{totalAmount?.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="d-flex justify-content-between small mb-2">
                    <span className="text-muted">Payment:</span>
                    <span className="badge bg-success-subtle text-success">{paymentStatus}</span>
                  </div>
                  <div className="d-flex justify-content-between small mb-2">
                    <span className="text-muted">Booked On:</span>
                    <span className="text-dark">{new Date(createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="text-center pt-3 border-top mt-3">
                  <div className="d-flex justify-content-center gap-1 mb-2" style={{ height: '36px' }}>
                    {[2,4,1,3,5,2,1,4,2,3,5,1,2,4,3,1,5,2,3,4,1,2,5,3,2,4,1,3].map((w, i) => (
                      <div key={i} className="bg-dark" style={{ width: `${w * 1.5}px`, height: '100%' }}></div>
                    ))}
                  </div>
                  <span className="small text-muted font-monospace">{bookingId}-ELECTRONIC-TICKET</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="card-footer bg-white p-3 d-flex justify-content-between align-items-center no-print">
          <span className="small text-muted">
            <i className="bi bi-info-circle me-1"></i> Please arrive at the airport 2 hours before departure.
          </span>
          <div className="d-flex gap-2">
            <button className="btn btn-outline-primary btn-sm px-3 rounded-pill fw-semibold" onClick={handlePrint}>
              <i className="bi bi-printer me-1"></i> Print Ticket
            </button>
            <button className="btn btn-primary btn-sm px-3 rounded-pill fw-semibold" onClick={handlePrint}>
              <i className="bi bi-download me-1"></i> Download PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TicketView;
