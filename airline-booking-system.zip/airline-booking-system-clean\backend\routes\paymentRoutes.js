const express = require('express');
const router = express.Router();
const { processPayment, getPaymentByBooking } = require('../controllers/paymentController');
const { protect } = require('../middleware/authMiddleware');

router.use(protect);

router.post('/', processPayment);
router.get('/:bookingId', getPaymentByBooking);

module.exports = router;
