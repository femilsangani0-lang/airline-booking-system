const Booking = require('../models/Booking');
const Flight = require('../models/Flight');

const generatePNR = () => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let pnr = 'SW-';
  for (let i = 0; i < 6; i++) {
    pnr += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return pnr;
};

const assignSeats = (count, startRow = 12) => {
  const letters = ['A', 'B', 'C', 'D', 'E', 'F'];
  const seats = [];
  let row = startRow;
  let colIndex = 0;
  for (let i = 0; i < count; i++) {
    seats.push(`${row}${letters[colIndex]}`);
    colIndex++;
    if (colIndex >= letters.length) {
      colIndex = 0;
      row++;
    }
  }
  return seats;
};

const createBooking = async (req, res) => {
  try {
    const {
      flightId,
      passengers,
      numberOfPassengers,
      travelClass = 'Economy',
      baseFare,
      taxes,
      serviceCharges = 150,
      totalAmount
    } = req.body;

    if (!flightId || !passengers || !passengers.length) {
      return res.status(400).json({ success: false, message: 'Flight and passenger details are required' });
    }

    const flight = await Flight.findById(flightId);
    if (!flight) {
      return res.status(404).json({ success: false, message: 'Selected flight not found' });
    }

    const passengerCount = numberOfPassengers || passengers.length;
    if (flight.availableSeats < passengerCount) {
      return res.status(400).json({
        success: false,
        message: `Only ${flight.availableSeats} seat(s) available on this flight`
      });
    }

    const assignedSeats = assignSeats(passengerCount, Math.floor(Math.random() * 20) + 5);
    const passengersWithSeats = passengers.map((p, idx) => ({
      fullName: p.fullName,
      gender: p.gender,
      dateOfBirth: p.dateOfBirth,
      passportOrId: p.passportOrId,
      email: p.email || req.user.email,
      phone: p.phone || req.user.phone,
      seatNumber: assignedSeats[idx] || `${idx + 10}A`
    }));

    const calcBaseFare = baseFare || (flight.price * passengerCount);
    const calcTaxes = taxes || Math.round(calcBaseFare * 0.12);
    const calcTotal = totalAmount || (calcBaseFare + calcTaxes + (serviceCharges || 150));

    const bookingId = generatePNR();

    const booking = await Booking.create({
      bookingId,
      userId: req.user._id,
      flightId: flight._id,
      passengers: passengersWithSeats,
      numberOfPassengers: passengerCount,
      travelClass: travelClass || flight.class,
      baseFare: calcBaseFare,
      taxes: calcTaxes,
      serviceCharges: serviceCharges || 150,
      totalAmount: calcTotal,
      bookingStatus: 'Confirmed',
      paymentStatus: 'Successful'
    });

    flight.availableSeats = Math.max(0, flight.availableSeats - passengerCount);
    await flight.save();

    const populatedBooking = await Booking.findById(booking._id).populate('flightId');

    res.status(201).json({
      success: true,
      message: 'Flight booked successfully!',
      data: populatedBooking
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getUserBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ userId: req.user._id })
      .populate('flightId')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: bookings.length,
      data: bookings
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getBookingById = async (req, res) => {
  try {
    const query = req.params.id.startsWith('SW-')
      ? { bookingId: req.params.id.toUpperCase() }
      : { _id: req.params.id };

    const booking = await Booking.findOne(query).populate('flightId');

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    if (booking.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Unauthorized to view this booking' });
    }

    res.status(200).json({
      success: true,
      data: booking
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    if (booking.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Unauthorized to cancel this booking' });
    }

    if (booking.bookingStatus === 'Cancelled') {
      return res.status(400).json({ success: false, message: 'This booking is already cancelled' });
    }

    booking.bookingStatus = 'Cancelled';
    await booking.save();

    const flight = await Flight.findById(booking.flightId);
    if (flight) {
      flight.availableSeats = Math.min(flight.totalSeats, flight.availableSeats + booking.numberOfPassengers);
      await flight.save();
    }

    res.status(200).json({
      success: true,
      message: 'Booking cancelled successfully. Refund initiated to original payment method.',
      data: booking
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { createBooking, getUserBookings, getBookingById, cancelBooking };
