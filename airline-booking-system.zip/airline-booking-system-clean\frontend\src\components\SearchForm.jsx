import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useBooking } from '../context/BookingContext';

const airportOptions = [
  { city: 'Mumbai', code: 'BOM', label: 'Mumbai (BOM)' },
  { city: 'Delhi', code: 'DEL', label: 'Delhi (DEL)' },
  { city: 'Bangalore', code: 'BLR', label: 'Bangalore (BLR)' },
  { city: 'Ahmedabad', code: 'AMD', label: 'Ahmedabad (AMD)' },
  { city: 'Goa', code: 'GOI', label: 'Goa (GOI)' },
  { city: 'Dubai', code: 'DXB', label: 'Dubai (DXB)' }
];

const SearchForm = ({ isHero = false }) => {
  const navigate = useNavigate();
  const { searchParams, updateSearch } = useBooking();

  const [from, setFrom] = useState(searchParams.from || 'Mumbai (BOM)');
  const [to, setTo] = useState(searchParams.to || 'Delhi (DEL)');
  const [departureDate, setDepartureDate] = useState(searchParams.departureDate || new Date().toISOString().split('T')[0]);
  const [returnDate, setReturnDate] = useState(searchParams.returnDate || '');
  const [passengers, setPassengers] = useState(searchParams.passengers || 1);
  const [travelClass, setTravelClass] = useState(searchParams.travelClass || 'Economy');
  const [tripType, setTripType] = useState(searchParams.tripType || 'one-way');

  const handleSwap = () => {
    const temp = from;
    setFrom(to);
    setTo(temp);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    updateSearch({
      from,
      to,
      departureDate,
      returnDate: tripType === 'round-trip' ? returnDate : '',
      passengers: Number(passengers),
      travelClass,
      tripType
    });
    navigate('/flights');
  };

  return (
    <div className={`bg-white p-3 p-md-4 rounded-4 ${isHero ? 'hero-search-card' : 'shadow-sm border'}`}>
      <div className="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3 pb-2 border-bottom">
        <div className="d-flex gap-3">
          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="tripType"
              id="oneWay"
              value="one-way"
              checked={tripType === 'one-way'}
              onChange={(e) => setTripType(e.target.value)}
            />
            <label className="form-check-label fw-semibold text-dark" htmlFor="oneWay">
              One Way
            </label>
          </div>
          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="tripType"
              id="roundTrip"
              value="round-trip"
              checked={tripType === 'round-trip'}
              onChange={(e) => setTripType(e.target.value)}
            />
            <label className="form-check-label fw-semibold text-dark" htmlFor="roundTrip">
              Round Trip
            </label>
          </div>
        </div>

        <div className="d-flex align-items-center gap-2">
          <label className="small text-muted fw-semibold">Class:</label>
          <select
            className="form-select form-select-sm rounded-pill fw-medium"
            value={travelClass}
            onChange={(e) => setTravelClass(e.target.value)}
          >
            <option value="Economy">Economy</option>
            <option value="Business">Business</option>
            <option value="All">All Classes</option>
          </select>
        </div>
      </div>

      <form onSubmit={handleSearch}>
        <div className="row g-2 align-items-center">
          <div className="col-12 col-md-6 col-lg-3">
            <label className="small text-muted fw-bold mb-1">
              <i className="bi bi-geo-alt-fill text-primary me-1"></i> From
            </label>
            <select
              className="form-select py-2 fw-semibold"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              required
            >
              {airportOptions.map((opt) => (
                <option key={opt.code} value={opt.label} disabled={opt.label === to}>
                  {opt.city} ({opt.code})
                </option>
              ))}
            </select>
          </div>

          <div className="col-12 col-lg-auto d-none d-lg-flex justify-content-center pt-3">
            <button
              type="button"
              className="btn btn-outline-secondary rounded-circle p-2 shadow-sm"
              style={{ width: '38px', height: '38px', display: 'grid', placeItems: 'center' }}
              onClick={handleSwap}
              title="Swap Locations"
            >
              <i className="bi bi-arrow-left-right"></i>
            </button>
          </div>

          <div className="col-12 col-md-6 col-lg-3">
            <label className="small text-muted fw-bold mb-1">
              <i className="bi bi-geo-fill text-danger me-1"></i> To
            </label>
            <select
              className="form-select py-2 fw-semibold"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              required
            >
              {airportOptions.map((opt) => (
                <option key={opt.code} value={opt.label} disabled={opt.label === from}>
                  {opt.city} ({opt.code})
                </option>
              ))}
            </select>
          </div>

          <div className="col-6 col-md-4 col-lg-2">
            <label className="small text-muted fw-bold mb-1">
              <i className="bi bi-calendar-event text-primary me-1"></i> Departure
            </label>
            <input
              type="date"
              className="form-control py-2 fw-semibold"
              value={departureDate}
              min={new Date().toISOString().split('T')[0]}
              onChange={(e) => setDepartureDate(e.target.value)}
              required
            />
          </div>

          {tripType === 'round-trip' ? (
            <div className="col-6 col-md-4 col-lg-2">
              <label className="small text-muted fw-bold mb-1">
                <i className="bi bi-calendar-check text-primary me-1"></i> Return
              </label>
              <input
                type="date"
                className="form-control py-2 fw-semibold"
                value={returnDate}
                min={departureDate}
                onChange={(e) => setReturnDate(e.target.value)}
                required={tripType === 'round-trip'}
              />
            </div>
          ) : (
            <div className="col-6 col-md-4 col-lg-2">
              <label className="small text-muted fw-bold mb-1">
                <i className="bi bi-people-fill text-primary me-1"></i> Passengers
              </label>
              <select
                className="form-select py-2 fw-semibold"
                value={passengers}
                onChange={(e) => setPassengers(e.target.value)}
              >
                <option value="1">1 Passenger</option>
                <option value="2">2 Passengers</option>
                <option value="3">3 Passengers</option>
                <option value="4">4 Passengers</option>
                <option value="5">5 Passengers</option>
              </select>
            </div>
          )}

          <div className="col-12 col-md-4 col-lg-auto ms-lg-auto pt-2 pt-lg-3">
            <button type="submit" className="btn btn-primary w-100 py-2 px-4 rounded-pill fw-bold shadow">
              <i className="bi bi-search me-2"></i> Search Flights
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default SearchForm;
