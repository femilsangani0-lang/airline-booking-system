import API from './api';

export const flightService = {
  getFlights: async (params = {}) => {
    const response = await API.get('/flights', { params });
    return response.data;
  },
  searchFlights: async (searchData) => {
    const response = await API.post('/flights/search', searchData);
    return response.data;
  },
  getFlightById: async (id) => {
    const response = await API.get(`/flights/${id}`);
    return response.data;
  },
  getFeaturedFlights: async () => {
    const response = await API.get('/flights/featured');
    return response.data;
  }
};
