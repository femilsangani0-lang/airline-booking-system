import API from './api';

export const paymentService = {
  processPayment: async (paymentData) => {
    const response = await API.post('/payments', paymentData);
    return response.data;
  },
  getPaymentByBooking: async (bookingId) => {
    const response = await API.get(`/payments/${bookingId}`);
    return response.data;
  }
};
