import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import AlertMessage from '../components/AlertMessage';

const SignupPage = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    gender: 'Male',
    password: '',
    confirmPassword: '',
    agreeTerms: false
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const { signup } = useAuth();
  const navigate = useNavigate();

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSignupSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters long');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (!formData.agreeTerms) {
      setError('You must agree to the Terms & Conditions');
      return;
    }

    setLoading(true);
    const res = await signup(formData);
    setLoading(false);

    if (res.success) {
      setSuccessMsg('Account created successfully! Redirecting to login...');
      setTimeout(() => {
        navigate('/login');
      }, 1800);
    } else {
      setError(res.message);
    }
  };

  return (
    <div className="container py-5 my-auto">
      <div className="row justify-content-center">
        <div className="col-12 col-md-10 col-lg-7">
          <div className="card border-0 shadow-lg rounded-4 overflow-hidden">
            <div className="bg-dark text-white p-4 text-center" style={{ backgroundColor: '#0b1f44' }}>
              <div className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-2" style={{ width: '48px', height: '48px' }}>
                <i className="bi bi-person-plus-fill fs-4"></i>
              </div>
              <h4 className="fw-bold mb-1">Create an Account</h4>
              <p className="small text-light opacity-75 mb-0">Join SkyWings Airlines for fast bookings and travel rewards</p>
            </div>

            <div className="card-body p-4 p-md-5">
              <AlertMessage message={error} onClose={() => setError('')} />
              <AlertMessage type="success" message={successMsg} />

              <form onSubmit={handleSignupSubmit}>
                <div className="row g-3">
                  <div className="col-12">
                    <label className="form-label small fw-bold text-secondary">Full Name</label>
                    <input
                      type="text"
                      className="form-control py-2"
                      placeholder="e.g. Rahul Sharma"
                      value={formData.fullName}
                      onChange={(e) => handleChange('fullName', e.target.value)}
                      required
                    />
                  </div>

                  <div className="col-12 col-md-6">
                    <label className="form-label small fw-bold text-secondary">Email Address</label>
                    <input
                      type="email"
                      className="form-control py-2"
                      placeholder="name@example.com"
                      value={formData.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      required
                    />
                  </div>

                  <div className="col-12 col-md-6">
                    <label className="form-label small fw-bold text-secondary">Phone Number</label>
                    <input
                      type="tel"
                      className="form-control py-2"
                      placeholder="9876543210"
                      value={formData.phone}
                      onChange={(e) => handleChange('phone', e.target.value)}
                      required
                    />
                  </div>

                  <div className="col-6 col-md-6">
                    <label className="form-label small fw-bold text-secondary">Date of Birth</label>
                    <input
                      type="date"
                      className="form-control py-2"
                      max={new Date().toISOString().split('T')[0]}
                      value={formData.dateOfBirth}
                      onChange={(e) => handleChange('dateOfBirth', e.target.value)}
                      required
                    />
                  </div>

                  <div className="col-6 col-md-6">
                    <label className="form-label small fw-bold text-secondary">Gender</label>
                    <select
                      className="form-select py-2"
                      value={formData.gender}
                      onChange={(e) => handleChange('gender', e.target.value)}
                      required
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div className="col-12 col-md-6">
                    <label className="form-label small fw-bold text-secondary">Password</label>
                    <input
                      type="password"
                      className="form-control py-2"
                      placeholder="At least 6 characters"
                      value={formData.password}
                      onChange={(e) => handleChange('password', e.target.value)}
                      required
                    />
                  </div>

                  <div className="col-12 col-md-6">
                    <label className="form-label small fw-bold text-secondary">Confirm Password</label>
                    <input
                      type="password"
                      className="form-control py-2"
                      placeholder="Re-enter password"
                      value={formData.confirmPassword}
                      onChange={(e) => handleChange('confirmPassword', e.target.value)}
                      required
                    />
                  </div>

                  <div className="col-12">
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id="agreeTerms"
                        checked={formData.agreeTerms}
                        onChange={(e) => handleChange('agreeTerms', e.target.checked)}
                        required
                      />
                      <label className="form-check-label small text-secondary" htmlFor="agreeTerms">
                        I agree to the <a href="#terms" className="text-primary text-decoration-none">Terms & Conditions</a> and <a href="#privacy" className="text-primary text-decoration-none">Privacy Policy</a>
                      </label>
                    </div>
                  </div>

                  <div className="col-12 mt-4">
                    <button
                      type="submit"
                      className="btn btn-primary w-100 py-2 rounded-pill fw-bold shadow-sm"
                      disabled={loading}
                    >
                      {loading ? (
                        <>
                          <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                          Creating Account...
                        </>
                      ) : (
                        'Create Account'
                      )}
                    </button>
                  </div>
                </div>
              </form>

              <p className="text-center small text-muted mb-0 mt-4">
                Already have an account?{' '}
                <Link to="/login" className="text-primary fw-bold text-decoration-none">
                  Sign In
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignupPage;
